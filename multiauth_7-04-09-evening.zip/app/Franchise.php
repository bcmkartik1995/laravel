<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Franchise extends Model
{
    use SoftDeletes;
    protected $dates = ['deleted_at'];

    public function frenchise_orders()
    {
        return $this->hasMany('App\Franchises_order', 'franchises_id');
    }

    public static function franchiseCount(){

        return Franchise::where('status','=','1')->count();
    }

    public function country()
    {
        return $this->belongsTo('App\Country','country_id');
    }
    public function state()
    {
        return $this->belongsTo('App\State','state_id');
    }
    public function city()
    {
        return $this->belongsTo('App\City','city_id');
    }
    public function user()
    {
        return $this->belongsTo('App\Models\Admin','user_id');
    } 
    
    public function franchise_categories()
    {
        return $this->hasMany('App\Franchise_categories', 'franchises_id');
    }
}
