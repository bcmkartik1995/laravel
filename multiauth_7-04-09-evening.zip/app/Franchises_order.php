<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Franchises_order extends Model
{

     protected $casts = [
        'order_details' => 'array'
    ];
    public function f_order()
    {
        return $this->belongsTo('App\Orders', 'orders_id');
    }
}
