<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class My_cart extends Model
{
    protected $casts = [
        'cart_data' => 'array'
    ];
}
