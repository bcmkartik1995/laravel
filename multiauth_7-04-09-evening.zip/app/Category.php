<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    
    public function subCategory()
    {
        return $this->hasMany('App\SubCategory', 'category_id');
    }

    public function packages()
    {
        return $this->hasMany('App\Package', 'category_id');
    }

    public function booking_detail()
    {
        return $this->hasMany('App\Booking_Detail');
    }

    public function services()
    {
        return $this->hasMany('App\Booking_Detail');
    }
    

}
