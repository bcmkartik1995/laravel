<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Service;
use App\Category;
use App\SubCategory;
use App\Franchise;
use App\Package;
use App\Package_service;
use App\Package_category;
use App\Package_subcategory;
use App\City;
use App\Package_cities;
use Auth;

use Illuminate\Support\Facades\DB;

class FranchisesPackageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = Auth::guard('admin')->user()->id;
        $franchises_id = Franchise::where('user_id',$user_id)->first();

        $data = DB::table('packages')
        ->where('franchises_id',$franchises_id->id)
        ->orderBy('id', 'DESC')
        ->get();

        return view('admin.franchises_package.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $user_id = Auth::guard('admin')->user()->id;
        $franchises_id = Franchise::where('user_id',$user_id)->first();
        $cities = City::where('status',1)->get();
        return view('admin.franchises_package.create',compact('categories','franchises_id','cities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_id' => 'required',
            'sub_category_id' => 'required',
            'service' => 'required',
            'city_id' => 'required',
            'title' => 'required',
            'discount_value' => 'required',
            'discount_type' => 'required',
            'more_description' => 'required',
            'minimum_require' => 'required | numeric',
        ]);

        
        $package = new Package;
        $package->franchises_id = $request->input('franchises_id');
        // $package->category_id = $request->input('category_id');
        // $package->sub_category_id = $request->input('sub_category_id');
        $package->title = $request->input('title');
        $package->discount_value = $request->input('discount_value');
        $package->discount_type = $request->input('discount_type');
        $package->more_description = $request->input('more_description');
        $package->minimum_require = $request->input('minimum_require');
        $package->status = 0;

        $package->save();
        
        if(!empty($request->category_id)){
            $categories_id = $request->category_id;
            $package_id = $package->id;

            $data = [];
            foreach($categories_id as $category_id){
                $data[] = [
                    'category_id' => $category_id,
                    'package_id' => $package_id
                ];
            }
            Package_category::insert($data);
        }

        if(!empty($request->sub_category_id)){
            $sub_categories_id = $request->sub_category_id;
            $package_id = $package->id;

            $data = [];
            foreach($sub_categories_id as $sub_category_id){
                $data[] = [
                    'sub_category_id' => $sub_category_id,
                    'package_id' => $package_id
                ];
            }
            Package_subcategory::insert($data);
        }
        
        if(!empty($request->service)){
            $services_id = $request->service;
            $package_id = $package->id;

            $data = [];
            foreach($services_id as $service_id) {
                $data[] = [
                    'service_id' => $service_id,
                    'package_id' => $package_id
                ];
            }
            Package_service::insert($data); 
        }

        if(!empty($request->city_id)){
            $cities_id = $request->city_id;
            $package_id = $package->id;

            $data = [];
            foreach($cities_id as $city_id) {
                $data[] = [
                    'city_id' => $city_id,
                    'package_id' => $package_id
                ];
            }
            Package_cities::insert($data); 
        }

        return redirect('admin/franchises-package')->with('Insert_Message','Data Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $package = Package::findOrFail($id);
        $categories = Category::all();
        $package_cat = Package_category::where('package_id',$id)->pluck('category_id')->toArray();
        $package_sub = Package_subcategory::where('package_id',$id)->pluck('sub_category_id')->toArray();
        $cities = City::where('status',1)->get();
        $package_city = Package_cities::where('package_id',$id)->pluck('city_id')->toArray();
        $subcategory = SubCategory::whereIn('category_id', $package_cat)->get();

        $services = DB::table('package_services as p')
        ->join('services as s', 'p.service_id', '=', 's.id')
        ->select('s.title', 'p.package_id', 'p.service_id','s.id')
        ->where('package_id',$id)
        ->get();

        return view('admin.franchises_package.edit', compact('package','categories','subcategory','services','package_cat','package_sub','package_city','cities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'category_id'=>'required',
            'sub_category_id'=>'required',
            'service'=>'required',
            'title' => 'required',
            'discount_value' => 'required',
            'discount_type' => 'required',
            'more_description' => 'required',
            'minimum_require' => 'required | numeric',
        ]);

        $package = Package::find($id);
        $package->franchises_id = $request->input('franchises_id');
        $package->title = $request->input('title');
        $package->discount_value = $request->input('discount_value');
        $package->discount_type = $request->input('discount_type');
        $package->more_description = $request->input('more_description');
        $package->minimum_require = $request->input('minimum_require');
        
        $package->save();

        $package_service = Package_service::where('package_id',$id)->pluck('service_id')->toArray();
        
       
        if(!empty($request->category_id)){
            $package_category = Package_category::where('package_id',$id)->pluck('category_id')->toArray();
            $categories_id = $request->category_id;
            $package_id = $package->id;

            $data = [];
            foreach($categories_id as $category_id) {
                if(!in_array($category_id, $package_category)){    
                    echo   $category_id;         
                    $data[] = [
                        'category_id' => $category_id,
                        'package_id' => $package_id
                    ];
                }
            }
            $deletable = array_diff($package_category, $categories_id);
            if(!empty($data)){
                Package_category::insert($data);
            }
            if(!empty($deletable)){
                $delete_package_category = Package_category::whereIn('category_id', $deletable)->where('package_id',$id);
                $delete_package_category->delete();
            }
        }

        if(!empty($request->sub_category_id)){
            $package_subcategory = Package_subcategory::where('package_id',$id)->pluck('sub_category_id')->toArray();
            $sub_categories_id = $request->sub_category_id;
            $package_id = $package->id;

            $data = [];
            foreach($sub_categories_id as $sub_category_id) {
                if(!in_array($sub_category_id, $package_subcategory)){    
                    echo   $sub_category_id;         
                    $data[] = [
                        'sub_category_id' => $sub_category_id,
                        'package_id' => $package_id
                    ];
                }
            }
            $deletable = array_diff($package_subcategory, $sub_categories_id);
            if(!empty($data)){
                Package_subcategory::insert($data);
            }
            if(!empty($deletable)){
                $delete_package_subcategory = Package_subcategory::whereIn('sub_category_id', $deletable)->where('package_id',$id);
                $delete_package_subcategory->delete();
            }
        }

        if(!empty($request->service)){
            $package_service = Package_service::where('package_id',$id)->pluck('service_id')->toArray();
            $services_id = $request->service;
            $package_id = $package->id;
            
            $data = [];
            foreach($services_id as $service_id) {
                if(!in_array($service_id, $package_service)){    
                    echo   $service_id;         
                    $data[] = [
                        'service_id' => $service_id,
                        'package_id' => $package_id
                    ];
                }
            }
            $deletable = array_diff($package_service, $services_id);
            if(!empty($data)){
                Package_service::insert($data);
            }
            if(!empty($deletable)){
                $delete_package_services = Package_service::whereIn('service_id', $deletable)->where('package_id',$id);
                $delete_package_services->delete();
            }
        }

        if(!empty($request->city_id)){
            $package_city = Package_cities::where('package_id',$id)->pluck('city_id')->toArray();
            $cities_id = $request->city_id;
            $package_id = $package->id;
            
            $data = [];
            foreach($cities_id as $city_id) {
                if(!in_array($city_id, $package_city)){    
                    echo   $city_id;         
                    $data[] = [
                        'city_id' => $city_id,
                        'package_id' => $package_id
                    ];
                }
            }
            $deletable = array_diff($package_city, $cities_id);
            if(!empty($data)){
                Package_cities::insert($data);
            }
            if(!empty($deletable)){
                $delete_package_city = Package_cities::whereIn('city_id', $deletable)->where('package_id',$id);
                $delete_package_city->delete();
            }
        }
        
        return redirect('admin/franchises-package')->with('update_message','Data Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $package = Package::find($id);
        $package->delete();
        Package_category::where('package_id',$id)->delete();
        Package_subcategory::where('package_id',$id)->delete();
        Package_service::where('package_id',$id)->delete();
        Package_cities::where('package_id',$id)->delete();
        
        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }
}
