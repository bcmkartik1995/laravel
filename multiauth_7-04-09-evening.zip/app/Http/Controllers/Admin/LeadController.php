<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Lead;
use App\Country;
use App\State;
use App\City;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class LeadController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Lead::with(['country' => function ($query) {
            $query->select('name','id');
        }])
        ->with(['state' => function ($query) {
            $query->select('name','id');
        }])
        ->with(['city' => function ($query) {
            $query->select('name','id');
        }])
        ->select('id','country_id','state_id','city_id','name','email','skill','phone','status')
        ->get();

        // $data = DB::table('leads as l')
        // ->join('countries as c', 'l.country_id', '=', 'c.id')
        // ->join('states as s', 'l.state_id', '=', 's.id')
        // ->join('cities as ct', 'l.city_id', '=', 'ct.id')
        // ->select('l.id','l.country_id','l.state_id','l.city_id','l.name','l.email','l.skill','l.phone','l.status','c.name as country_name','s.name as state_name','ct.name as city_name')
        // ->get();

        return view('admin.Lead.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $countries = Country::all();
        return view('admin.Lead.create',compact('countries'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'country_id'=>'required',
            'state_id'=>'required',
            'city_id'=>'required',
            'name' => 'required',
            'email' => 'required|email|unique:leads|unique:admins,email',
            'skill' => 'required',
            'mobile' => 'required|numeric|digits:10|unique:leads,phone|unique:admins,phone',
        ]);

        $lead = new Lead;
        $lead->country_id = $request->input('country_id');
        $lead->state_id = $request->input('state_id');
        $lead->city_id = $request->input('city_id');
        $lead->name = $request->input('name');
        $lead->email = $request->input('email');
        $lead->skill = $request->input('skill');
        $lead->phone = $request->input('mobile');

        $lead->save();
        return redirect('admin/lead')->with('Insert_Message','Data Created Successfully');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $leads = Lead::findOrFail($id);
        $countries = Country::all();
        $states = State::where('country_id',$leads->country_id)->get();
        $cities = City::where('state_id',$leads->state_id)->get();
        // echo '<pre>';
        // print_R($cities);die;
        return view('admin.Lead.edit', compact('leads','countries','states','cities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'country_id'=>'required',
            'state_id'=>'required',
            'city_id'=>'required',
            'name' => 'required',
            'email' => 'sometimes|required|email|unique:leads,email,'.$id,
            'skill' => 'required',
            'phone' => 'sometimes|required|numeric|digits:10|unique:leads,phone,'.$id,
        ]);

        $lead = Lead::find($id);
        $lead->country_id = $request->input('country_id');
        $lead->state_id = $request->input('state_id');
        $lead->city_id = $request->input('city_id');
        $lead->name = $request->input('name');
        $lead->email = $request->input('email');
        $lead->skill = $request->input('skill');
        $lead->phone = $request->input('mobile');

        $lead->save();
        return redirect('admin/lead')->with('update_message','Data Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $leads = Lead::find($id);
        $leads->delete();
        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }
}
