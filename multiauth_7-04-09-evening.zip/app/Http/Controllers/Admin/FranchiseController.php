<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Role;
use App\Franchise;
use App\Category;
use App\SubCategory;
use App\Country;
use App\State;
use App\Lead;
use App\User;
use App\City;
use App\Franchise_category;
use Illuminate\Support\Facades\DB;

class FranchiseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function create(Request $request)
    {
        $categories = Category::all();
        $user_id = $request->id;
        $countries = Country::all();
        $franchise = Franchise::where('user_id',$user_id)->first();
        
        return view('admin.Franchise.create',compact('countries','user_id','franchise','categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'country_id'=>'required',
            'state_id'=>'required',
            'city_id'=>'required',
            'category_id'=>'required',
            'user_id'=>'required',
            'address_1'=>'required',
            'longitude'=>'required',
            'latitude'=>'required',
            'pincode'=>'required',
            'franchise_name'=>'required',
            'email'=>'required | email',
            'mobile'=>'required | numeric | digits:10',
            'commission'=>'required',
            'hour'=>'required',
            'minute'=>'required',
        ]);

        $franchise = new Franchise;
        $franchise->country_id = $request->input('country_id');
        $franchise->state_id = $request->input('state_id');
        $franchise->city_id = $request->input('city_id');
        // $franchise->category_id = $request->input('category_id');
        // $franchise->sub_category_id = $request->input('sub_category_id');
        $franchise->user_id = $request->input('user_id');
        $franchise->address_1 =$request->input('address_1');
        $franchise->address_2 = $request->input('address_2');
        $franchise->longitude = $request->input('longitude');
        $franchise->latitude = $request->input('latitude'); 
        $franchise->pincode = $request->input('pincode'); 
        $franchise->franchise_name = $request->input('franchise_name'); 
        $franchise->email = $request->input('email'); 
        $franchise->mobile = $request->input('mobile'); 
        $franchise->commission = $request->input('commission');
        $franchise->hour = $request->input('hour');
        $franchise->minute = $request->input('minute');
        
        $franchise->save();

        if(!empty($request->category_id)){
            $categories_id = $request->category_id;
            $franchises_id = $franchise->id;

            $data = [];
            foreach($categories_id as $category_id){
                $data[] = [
                    'category_id'=>$category_id,
                    'franchises_id'=>$franchises_id
                ];
            }
            Franchise_category::insert($data);
        }

        return redirect()->route('franchise-view')->with('Insert_Message','Data Created Successfully');
    }

    public function index()
    {
        $franchises = Franchise::with(['country' => function ($query) {
            $query->select('name','id');
        }])
        ->with(['state' => function ($query) {
            $query->select('name','id');
        }])
        ->with(['city' => function ($query) {
            $query->select('name','id');
        }])
        ->with(['user' => function ($query) {
            $query->select('name','id');
        }])
        ->select('id','country_id','state_id','city_id','address_1','user_id','address_2','longitude','latitude','pincode','franchise_name','email','mobile','commission','status','created_at','updated_at','hour','minute')
        ->get();
        
        return view('admin.Franchise.index',compact('franchises'));
    }

    public function edit($id)
    {
        $franchise = Franchise::findOrFail($id);
        $countries = Country::all();
        $categories = Category::all();
        $franchise_cat = Franchise_category::where('franchises_id',$id)->pluck('category_id')->toArray();
        $subcategory = SubCategory::where('category_id', $franchise->category_id)->get();
        $states = State::where('country_id',$franchise->country_id)->get();
        $cities = City::where('state_id',$franchise->state_id)->get();

        
        
        return view('admin.Franchise.edit', compact('franchise','countries','states','cities','categories','subcategory','franchise_cat'));
    }


    public function update(Request $request, $id)
    {
 
        $request->validate([
            'country_id'=>'required',
            'state_id'=>'required',
            'city_id'=>'required',
            'category_id'=>'required',
            'user_id'=>'required',
            'address_1'=>'required',
            'longitude'=>'required',
            'latitude'=>'required',
            'pincode'=>'required',
            'franchise_name'=>'required',
            'email'=>'required | email',
            'mobile'=>'required | numeric | digits:10',
            'commission'=>'required',
            'hour'=>'required',
            'minute'=>'required',
        ]);

        $franchise = Franchise::find($id);
        $franchise->country_id = $request->input('country_id');
        $franchise->state_id = $request->input('state_id');
        $franchise->city_id = $request->input('city_id');
        // $franchise->category_id = $request->input('category_id');
        // $franchise->sub_category_id = $request->input('sub_category_id');
        $franchise->user_id = $request->input('user_id');
        $franchise->address_1 =$request->input('address_1');
        $franchise->address_2 = $request->input('address_2');
        $franchise->longitude = $request->input('longitude');
        $franchise->latitude = $request->input('latitude'); 
        $franchise->pincode = $request->input('pincode'); 
        $franchise->franchise_name = $request->input('franchise_name'); 
        $franchise->email = $request->input('email'); 
        $franchise->mobile = $request->input('mobile'); 
        $franchise->commission = $request->input('commission');
        $franchise->hour = $request->input('hour');
        $franchise->minute = $request->input('minute');
       
        $franchise->save();

        if(!empty($request->category_id)){
            $franchise_category = Franchise_category::where('franchises_id',$id)->pluck('category_id')->toArray();
            $categories_id = $request->category_id;
            $franchises_id = $franchise->id;

            $data = [];
            foreach($categories_id as $category_id){
                if(!in_array($category_id, $franchise_category)){
                    $data[] = [
                        'category_id' => $category_id,
                        'franchises_id' => $franchises_id
                    ];
                }    
            }

            $deletable = array_diff($franchise_category, $categories_id);
            if(!empty($data)){
                Franchise_category::insert($data);
            }
            if(!empty($deletable)){
                $delete_franchise_cat = Franchise_category::whereIn('category_id', $deletable)->where('franchises_id',$id);
                $delete_franchise_cat->delete();
            }
        }

        return redirect()->route('franchise-view')->with('update_message','Data Updated Successfully');
    }

    public function delete($id)
    {
        $franchise = Franchise::find($id);
        $franchise->delete();
        Franchise_category::where('franchises_id',$id)->delete();

        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }
}
