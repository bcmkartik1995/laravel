<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Stevebauman\Location\Facades\Location;
use App\Franchises_order;
use App\Orders;
use App\Order_Details;
use App\User;
use App\Franchise;
use PDF;
use Mail;
use Auth;

class FranchisesOrdersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function index()
    {   
        
        $user = Auth::guard('admin')->user();
        
        $franchise_user = DB::table('franchises')
        ->where('user_id',$user->id)
        ->first();
        
        $franchises_orders = DB::table('franchises_orders as fo')
        ->join('orders as o','fo.orders_id','=','o.id')
        ->join('users as u','o.user_id','=','u.id')
        ->join('franchises as f','fo.franchises_id','=','f.id')    
        ->select('fo.id','fo.franchises_id','f.franchise_name','fo.orders_id','o.id as order_id','o.customer_address','o.user_id','u.name','o.pay_amount','u.latitude','u.longitude','u.ipaddress','fo.status','o.status as order_status')
        ->where('fo.franchises_id',$franchise_user->id)
        ->orderBy('id', 'DESC')
        ->get();
        
        // echo '<pre>';
        // print_R($franchises_orders);die;

        return view('admin.Franchises_order.index',compact('franchises_orders'));
    }

    public function store(Request $request)
    {
        
        $franchises_data = Franchises_order::where(['orders_id'=> $request->orders_id, 'status' => 1])->first();
        if(!empty($franchises_data)){
            return redirect('/admin/orders')->with('delete_message','Order Aleready Completed');
        }
        $franchises_data = Franchises_order::where(['orders_id'=> $request->orders_id, 'status' => 0])->first();
       
        if(!empty($franchises_data))
        {
            $franchises_data->franchises_id = $request->input('franchises_id');
            $franchises_data->save();
        }else{
            $franchises_order = new Franchises_order;
            $franchises_order->franchises_id = $request->input('franchises_id');
            $franchises_order->orders_id = $request->input('orders_id');
            $franchises_order->save();
        }

        return redirect('/admin/orders')->with('Insert_Message','Franchises Assign Successfully');
    }

    public function franchises_assign()
    {
        $franchises_orders = DB::table('franchises_orders as fo')
        ->join('orders as o','fo.orders_id','=','o.id')
        ->join('users as u','o.user_id','=','u.id')
        ->join('franchises as f','fo.franchises_id','=','f.id')
        ->select('fo.id','fo.franchises_id','f.franchise_name','fo.orders_id','o.id as order_id','o.customer_address','o.user_id','u.name','o.pay_amount','u.latitude','u.longitude','u.ipaddress','fo.status')
        ->orderBy('id', 'DESC')
        ->paginate(10);

        return view('admin.Franchises_assigned.index',compact('franchises_orders'));
    }

    public function franchises_invoice($id)
    {
        
        // $booking = Orders::where('orders.id',$id)
        // ->join('franchises_orders as fo','fo.orders_id','=','orders.id')
        // ->join('users as u','orders.user_id','=','u.id')
        // ->join('franchises as f','fo.franchises_id','=','f.id')
        // ->select('fo.id','fo.franchises_id','fo.status','fo.orders_id','orders.id as order_id','orders.customer_email','orders.customer_name','orders.customer_phone','orders.customer_address','orders.user_id','orders.order_number','f.address_1','f.address_2','f.franchise_name','f.email','f.mobile','u.name','orders.pay_amount','u.latitude','u.longitude','u.ipaddress','orders.cart','orders.created_at')
        // ->where('fo.status',1)
        // ->first();
        
        $booking = Orders::where('orders.id',$id)
        ->join('franchises_orders as fo','fo.orders_id','=','orders.id')
        ->join('users as u','orders.user_id','=','u.id')
        ->join('franchises as f','fo.franchises_id','=','f.id')
        ->select('fo.id','fo.franchises_id','fo.status','fo.orders_id','orders.id as order_id','orders.customer_email','orders.customer_name','orders.customer_phone','orders.customer_address','orders.user_id','orders.order_number','f.address_1','f.address_2','f.franchise_name','f.email','f.mobile','u.name','orders.pay_amount','u.latitude','u.longitude','u.ipaddress','orders.cart','orders.created_at')
        ->where('fo.status',1)
        ->first();


        return view('admin.Franchises_order.invoice',compact('booking'));
    }

    public function franchises_invoice_print($id)
    {
        $booking = Orders::where('orders.id',$id)
        ->join('franchises_orders as fo','fo.orders_id','=','orders.id')
        ->join('users as u','orders.user_id','=','u.id')
        ->join('franchises as f','fo.franchises_id','=','f.id')
        ->select('fo.id','fo.franchises_id','fo.status','fo.orders_id','orders.id as order_id','orders.customer_email','orders.customer_name','orders.customer_phone','orders.customer_address','orders.user_id','orders.order_number','f.address_1','f.address_2','f.franchise_name','f.email','f.mobile','u.name','orders.pay_amount','u.latitude','u.longitude','u.ipaddress','orders.cart','orders.created_at')
        ->where('fo.status',1)
        ->first();
        
        //$data = ['title' => 'Welcome to ItSolutionStuff.com'];
        //$dompdf->set_base_path("/www/public/css/");
       // return view('admin.Franchises_order.orderPdf',compact('booking'));
        $data["order_number"]= $booking['order_number'];

        $data['custom'] = json_encode($booking);
        $pdf = PDF::loadView('admin.Franchises_order.orderPdf',$data);
        return $pdf->download($data["order_number"].'.pdf');

        //return $pdf->stream($booking->order_number.'.pdf');
    }

    public function franchises_invoice_send($id)
    {
        $booking = Orders::where('orders.id',$id)
        ->join('franchises_orders as fo','fo.orders_id','=','orders.id')
        ->join('users as u','orders.user_id','=','u.id')
        ->join('franchises as f','fo.franchises_id','=','f.id')
        ->select('fo.id','fo.franchises_id','fo.status','fo.orders_id','orders.id as order_id','orders.customer_email','orders.customer_name','orders.customer_phone','orders.customer_address','orders.user_id','orders.order_number','f.address_1','f.address_2','f.franchise_name','f.email','f.mobile','u.name','orders.pay_amount','u.latitude','u.longitude','u.ipaddress','orders.cart','orders.created_at')
        ->where('fo.status',1)
        ->first()->toArray();


        

        $data["customer_email"]= $booking['customer_email'];

        $data['custom'] = json_encode($booking);
        $pdf = PDF::loadView('admin.Franchises_order.orderPdf',$data);
        //echo 'dsdsdsdsd';die;
        Mail::send('admin.Franchises_order.email.invoice', $data, function($message)use($data, $pdf) {
            
        $message->to($data['customer_email'])
            ->subject('Send Mail from Laravel')
            //->body('hi')
            ->attachData($pdf->output(),"test.pdf");
        });
        
        return redirect()->back()->with('Insert_Message', 'Mail sent successfully');
    }

}
