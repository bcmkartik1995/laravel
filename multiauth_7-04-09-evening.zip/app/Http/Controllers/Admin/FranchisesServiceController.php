<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Service;
use App\Category;
use App\SubCategory;
use App\Franchise;
use App\City;
use App\Service_cities;
use Illuminate\Support\Facades\DB;
use Auth;

class FranchisesServiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = Auth::guard('admin')->user()->id;
        $franchises_id = Franchise::where('user_id',$user_id)->first();
        
        $services = Service::with(['category' => function ($query) {
            $query->select('title','id');
        }])
        ->select('id','title','image','hour','minute','description','long_description','status','category_id','franchises_id','sub_category_id')
        ->orderBy('id', 'DESC')
        ->where('franchises_id',$franchises_id->id)
        ->with(['sub_category' => function ($query) {
            $query->select('title','id');
        }])
        ->get();  

        return view('admin.franchises_service.index',compact('services'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $user_id = Auth::guard('admin')->user()->id;
        $franchises_id = Franchise::where('user_id',$user_id)->first();

        $cities = City::where('status',1)->get();

        return view('admin.franchises_service.create',compact('categories','franchises_id','cities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_id'=>'required',
            'sub_category_id'=>'required',
            'city_id'=>'required',
            'title' => 'required',
            'image' => 'required',
            'price' => 'required',
            'hour' => 'required',
            'minute' => 'required',
            'description' => 'required',
            'franchises_id' => 'required',
        ]);

        $service = new Service;
        $service->franchises_id = $request->input('franchises_id');
        $service->category_id = $request->input('category_id');
        $service->sub_category_id = $request->input('sub_category_id');
        $service->title = $request->input('title');

        $image = $request->file('image');
        $imagename = time().'.'.$image->extension();
        $image->move(public_path('assets/images/servicelogo'),$imagename);
        $service->image = $imagename;

        $service->price = $request->input('price');
        $service->hour = $request->input('hour');
        $service->minute = $request->input('minute');
        $service->description = $request->input('description');
        $service->long_description = $request->input('long_description');
        $service->status = 0;
        $service->save();

        if(!empty($request->city_id)){
            $cities_id = $request->city_id;
            $service_id = $service->id;

            $data = [];
            foreach($cities_id as $city_id){
                $data[] = [
                    'city_id' => $city_id,
                    'service_id' => $service_id
                ];
            }
            Service_cities::insert($data);
        }

        return redirect('admin/franchises-service')->with('Insert_Message','Data Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $service = Service::findOrFail($id);
        $categories = Category::all();
        $subcategory = SubCategory::where('category_id', $service->category_id)->get();

        $cities = City::where('status',1)->get();
        $service_city = Service_cities::where('service_id',$id)->pluck('city_id')->toArray();

        return view('admin.franchises_service.edit', compact('service','categories','subcategory','cities','service_city'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'category_id'=>'required',
            'sub_category_id'=>'required',
            'title' => 'required',
            'price' => 'required',
            'hour' => 'required',
            'minute' => 'required',
            'description' => 'required',
        ]);

        $service = Service::find($id);
        $service->franchises_id = $request->input('franchises_id');
        $service->category_id = $request->input('category_id');
        $service->sub_category_id = $request->input('sub_category_id');
        $service->title = $request->input('title');

        if($request->image != ''){
            $image = $request->file('image');
            $imagename = time().'.'.$image->extension();
            $image->move(public_path('assets/images/servicelogo'),$imagename);
            $service->image = $imagename;
        }

        $service->price = $request->input('price');
        $service->hour = $request->input('hour');
        $service->minute = $request->input('minute');
        $service->description = $request->input('description');
        $service->long_description = $request->input('long_description');

        $service->save();

        if(!empty($request->city_id)){
            $service_city = Service_cities::where('service_id',$id)->pluck('city_id')->toArray();
            $cities_id = $request->city_id;
            $service_id = $service->id;

            $data = [];
            foreach($cities_id as $city_id) {
                if(!in_array($city_id, $service_city)){    
                    echo   $city_id;         
                    $data[] = [
                        'city_id' => $city_id,
                        'service_id' => $service_id
                    ];
                }
            }
            $deletable = array_diff($service_city, $cities_id);
            if(!empty($data)){
                Service_cities::insert($data);
            }
            if(!empty($deletable)){
                $delete_service_city = Service_cities::whereIn('city_id', $deletable)->where('service_id',$id);
                $delete_service_city->delete();
            }
        }
        
        return redirect('admin/franchises-service')->with('update_message','Data Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $service = Service::find($id);
        $service->delete();
        Service_cities::where('service_id',$id)->delete();

        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }
}
