<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\GiftCard;
use Carbon\Carbon;

class GiftController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $gifts = GiftCard::get();
        return view('admin.Gift.index',compact('gifts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.Gift.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'gift_value' => 'required',
            'image' => 'required',
            'valid_from' => 'required',
            'valid_to' => 'required',
            'description' => 'required',
        ]);

        $gifts = new GiftCard;
        $gifts->title = $request->input('title');
        $gifts->description = $request->input('description');
        $gifts->gift_value = $request->input('gift_value');

        $image = $request->file('image');
        $imagename = time().'.'.$image->extension();
        $image->move(public_path('assets/images/giftsimage'),$imagename);
        $gifts->image = $imagename;

        $gifts->valid_from = $request->input('valid_from');
        $gifts->valid_to = $request->input('valid_to');

        $gifts->save();
        return redirect('admin/gift-card')->with('Insert_Message','Data Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $gifts = GiftCard::findOrFail($id);
        return view('admin.Gift.edit',compact('gifts'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validations = [
            'title' => 'required',
            'gift_value' => 'required',
            'image' => 'required',
            'valid_from' => 'required',
            'valid_to' => 'required',
            'description' => 'required',
        ];
        $gifts = GiftCard::find($id);   
        $gifts->title = $request->input('title');
        $gifts->description = $request->input('description');
        $gifts->gift_value = $request->input('gift_value');

        if($request->image != ''){

            $image = $request->file('image');
            $imagename = time().'.'.$image->extension();
            $image->move(public_path('assets/images/giftsimage'),$imagename);
            $gifts->image = $imagename;
        }

        $gifts->valid_from = $request->input('valid_from');
        $gifts->valid_to = $request->input('valid_to');

        
        $gifts->save();
        return redirect('admin/gift-card')->with('update_message','Data Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $gifts = GiftCard::findOrFail($id);
        $gifts->delete();
        
        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }
}
