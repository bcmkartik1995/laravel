<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Package;
use App\Package_service;
use App\Service;
use App\Category;
use App\SubCategory;
use App\Country;
use App\State;
use App\City;
use App\Lead;
use App\Orders;
use App\Franchises_order;
use App\Package_subcategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use Illuminate\Pagination\Paginator;

class AjaxController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function ajax_subcat(Request $request){
        //print_R($request->cat_id);die;
        $subcategories = SubCategory::where('category_id', $request->cat_id)->select('title','id')->get();
        //print_R($subcategories);die;
        return response()->json($subcategories);
    }
    public function edit_ajax_subcat(Request $request){
        //$cat_id = Input::get('cat_id');
        $subcategories = SubCategory::where('category_id','=',$request->cat_id)->select('title','id')->get();
        //print_R($subcategories);die;
        return response()->json($subcategories);
    }
    
    public function best_subcat(Request $request){
        
        $subcategories = SubCategory::where('category_id', $request->cat_id)->select('title','id')->get();
        return response()->json($subcategories);
    }

    public function best_service(Request $request){
        
        $subcategories = Service::where('sub_category_id', $request->cat_id)->select('title','id')->get();
        return response()->json($subcategories);
    }

    public function package_subcat(Request $request){
      
        $package_id = isset($request->package_id) && !empty($request->package_id) ? $request->package_id : null;
        $sub_category_id = [];
        if($package_id){
            $sub_category_id = Package_subcategory::where('package_id', $package_id)->pluck('sub_category_id')->toArray();
        }
        
        $subcategories = SubCategory::whereIn('category_id', $request->cat_id)->select('title','id')
        ->get()
        ->map(function($query) use($sub_category_id){
            $query->selected = in_array($query->id, $sub_category_id) ? true : false;
            return $query;
        });
        //print_R($subcategories);die;
        return response()->json($subcategories);
    }
    
    public function package_service(Request $request){
        //print_R($request->all());die;
        $package_id = isset($request->package_id) && !empty($request->package_id) ? $request->package_id : null;
        $service_id = [];
        if($package_id){
            $service_id = Package_service::where('package_id', $package_id)->pluck('service_id')->toArray();
        }
       
        $service = Service::whereIn('sub_category_id',$request->cat_id)->select('title','id')
        ->get()
        ->map(function($query) use($service_id){
            $query->selected = in_array($query->id, $service_id) ? true : false;
            return $query;
        });
        
        return response()->json($service);
    }

    public function offer_subcat(Request $request){
        //$cat_id = Input::get('cat_id');
        $subcategories = SubCategory::where('category_id','=',$request->cat_id)->select('title','id')->get();
        //print_R($subcategories);die;
        return response()->json($subcategories);
    }

    public function offer_service(Request $request){
        //$cat_id = Input::get('cat_id');
        $subcategories = Service::where('sub_category_id','=',$request->cat_id)->select('title','id')->get();
        //print_R($subcategories);die;
        return response()->json($subcategories);
    }

    public function franchises_subcat(Request $request){
        //$cat_id = Input::get('cat_id');
        $subcategories = SubCategory::where('category_id','=',$request->cat_id)->select('title','id')->get();
        //print_R($subcategories);die;
        return response()->json($subcategories);
    }

    public function ajax_country(Request $request){
       
        $state = State::where('country_id','=',$request->country_id)->get();
        //print_R($state);die;
        return response()->json($state);
    }

    public function ajax_state(Request $request){
       
        $city = City::where('state_id','=',$request->state_id)->get();
        //print_R($city);die;
        return response()->json($city);
    }

    public function lead_status(Request $request){
        $leads = Lead::find($request->id);
        $leads->status = $request->action;
        // print_R($leads);die;
        $leads->update();
        return response()->json($leads);
    }

    public function orders_status(Request $request){
        //echo 'dsdsdsd';die;
        // /print_R($request->status);die;
        $bookings = Orders::find($request->id);
        $bookings->status = $request->status;
        //print_R($bookings);die;
        $bookings->update();
        return response()->json($bookings);
    }
    public function franchises_orders(Request $request){

        $franchises_orders = Franchises_order::find($request->id);
        $franchises_orders->status = $request->action;
        //print_R($franchises_orders);die;
        $franchises_orders->update();
        return response()->json($franchises_orders);
    }
    
}