<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Pagination\Paginator;
use Auth;


class CategoriesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // echo '<pre>';
        // print_R(auth::user());die;
        // echo"ssss";die;
        $categories = Category::get();
        //print_r($categories);die;
        return view('admin.Categories.index',compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.Categories.create');
    }

    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|unique:categories,title,NULL,id,deleted_at,NULL',
            'logo' => 'required',
            'description' => 'required',
        ]);

        $category = new Category;
        $category->title = $request->input('title');
        $slug = Str::slug($category->title,'-');
        $category->slug = $slug;
        $category->description = $request->input('description');
        
        $image = $request->file('logo');
        $imagename = time().'.'.$image->extension();
        $image->move(public_path('assets/images/categorylogo'),$imagename);
        $category->logo = $imagename;

        $category->save();

        return redirect('admin/categories')->with('Insert_Message','Data Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = Category::findOrFail($id);
        
        return view('admin.Categories.edit', compact('categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|unique:categories,title,'.$id.',id,deleted_at,NULL',
            'description' => 'required',
        ]);

        $category = Category::find($id);
        
        $category->title = $request->input('title');
        $slug = Str::slug($category->title,'-');
        $category->slug = $slug;
        $category->description = $request->input('description');
        
        if($request->logo != ''){

            $image = $request->file('logo');
            $imagename = time().'.'.$image->extension();
            $image->move(public_path('assets/images/categorylogo'),$imagename);
            $category->logo = $imagename;
        }
      
        $category->save();
        
        return redirect('admin/categories')->with('update_message','Data Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category = Category::find($id);
        $category->delete();
        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
        //return redirect('admin/categories')->with('delete_message','Data Deleted successfully');
    }
}
