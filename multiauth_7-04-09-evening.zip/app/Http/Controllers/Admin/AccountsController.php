<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Stevebauman\Location\Facades\Location;
use App\Orders;
use App\Franchise;

class AccountsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    
    public function income(){

        $Orders = Orders::where(['orders.status' => 'completed'])
            ->select(['orders.pay_amount','orders.method', 'f.commission'])
            ->join("franchises_orders AS fo",function($join){
                $join->on('orders.id', '=', 'fo.orders_id')->where('fo.status', 1);
            })
            ->join("franchises AS f",function($join){
                $join->on('f.id', '=', 'fo.franchises_id');
            })
            ->get();

        $total_earnings = 0;
        $total_income = 0;
        $total_commission = 0;
        if($Orders->count()){
            foreach($Orders as $order){
                $total_earnings += $order->pay_amount;
                
                $commission = ($order->pay_amount * $order->commission) / 100;

                $total_income += $order->pay_amount - $commission;
                $total_commission += $commission;
            }
        }

        return view('admin.accounts.income', compact('total_earnings','total_income','total_commission'));
    }

    public function franchise_fees(){

        $franchises = DB::table('franchises as f')
            ->join('users as u', 'f.user_id', '=', 'u.id')
            ->select('f.id','f.franchise_name','f.email','f.mobile','f.commission','f.status','f.created_at','f.updated_at','u.name as user_name')
            ->orderBy('id', 'DESC')
            ->paginate(10);
            
            return view('admin.accounts.franchise_fees',compact('franchises'));
    }

    public function franchise_outstanding(){

        $franchises = Franchise::with(['frenchise_orders' => function ($query) {
                $query->with(['f_order' => function($q){
                    $q->select('id','method','pay_amount','status')->where('status', 'completed');
                }])
                ->where(['status' => 1]);
            }])
           ->join('users as u', 'franchises.user_id', '=', 'u.id')
            ->select('franchises.id','franchises.franchise_name','franchises.created_at','franchises.updated_at','u.name as user_name','franchises.commission')
            ->orderBy('franchises.id', 'DESC')
            ->paginate(10);

        foreach($franchises as $franchise){

            $franchise->credit_amount = 0;
            $franchise->debit_amount = 0;
            if(!empty($franchise->frenchise_orders)){
                foreach($franchise->frenchise_orders as $frenchise_order){
                    if(!empty($frenchise_order->f_order) && $frenchise_order->f_order->status == 'completed'){

                        if($frenchise_order->f_order->method == 'Cash On Delivery'){
                            $pay_amount = $frenchise_order->f_order->pay_amount;
                            $commission = ($pay_amount * $franchise->commission) / 100;

                            $franchise->debit_amount = $pay_amount - $commission;
                        }
                    }
                }
            }
        }
            // echo'<pre>';
            //  print_R($franchises);
            // die;
        return view('admin.accounts.franchise_outstanding',compact('franchises'));
    }


    
}
