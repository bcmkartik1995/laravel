<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Service;
use App\Category;
use App\SubCategory;
use App\City;
use App\Service_cities;
use App\Services_ratings;
use App\service_media;
use App\Best_service;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use Illuminate\Pagination\Paginator;

class ServicesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $services = Service::with(['category' => function ($query) {
            $query->select('title','id');
        }])
        ->select('id','title','image','banner','hour','minute','description','long_description','status','category_id','franchises_id','sub_category_id')
        ->orderBy('id', 'DESC')
        ->with(['owner' => function ($query) {
            $query->select('franchise_name','id');
        }])
        ->with(['sub_category' => function ($query) {
            $query->select('title','id');
        }])
        ->get();  

        //$services = DB::table('services')->paginate(10);
        return view('admin.Services.index',compact('services'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $cities = City::where('status',1)->get();
        return view('admin.Services.create',compact('categories','cities'));
    }

    // public function fetchSubCategory(Request $request)
    // {
    //     $subcategory = SubCategory::where("category_id",$request->category_id)->get(["name", "id"]);
    //     return view('admin.Services.create',compact('subcategory'));
    // }
    // $('#category_id').change(function(){
    //     category_id = $(this).val();
    // })
    /**ss
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // echo '<pre>';
        // print_R($request->all());die;
        $request->validate([
            'category_id'=>'required',
            'sub_category_id'=>'required',
            'city_id'=>'required',
            'title' => 'required',
            'price' => 'required',
            'hour' => 'required',
            'minute' => 'required',
            'description' => 'required',
            'image' => 'required|mimes:png',
            'banner' => 'required|mimes:jpg,png,jpeg',
        ]);

        $service = new Service;
        $service->category_id = $request->input('category_id');
        $service->sub_category_id = $request->input('sub_category_id');
        $service->title = $request->input('title');

        $image = $request->file('image');
        $imagename = time().'.'.$image->extension();
        $image->move(public_path('assets/images/servicelogo'),$imagename);
        $service->image = $imagename;

        $banner = $request->file('banner');
        $bannername = time().'.'.$banner->extension();
        $banner->move(public_path('assets/images/servicebanner'),$bannername);
        $service->banner = $bannername;

        $service->price = $request->input('price');
        $service->hour = $request->input('hour');
        $service->minute = $request->input('minute');
        $service->description = $request->input('description');
        $service->long_description = $request->input('long_description');
        // echo '<pre>';
        // print_R($service);die;
        $service->save();

        if(!empty($request->city_id)){
            $cities_id = $request->city_id;
            $service_id = $service->id;

            $data = [];
            foreach($cities_id as $city_id){
                $data[] = [
                    'city_id' => $city_id,
                    'service_id' => $service_id
                ];
            }
            Service_cities::insert($data);
        }


        if(!empty($request->multi_media)){
            $medias_id = $request->multi_media;
            $service_id = $service->id;
            
            $data = [];
            foreach($medias_id as $media_id){

                $multi_media = $media_id;
                $medianame = rand().time().'.'.$multi_media->extension();
                $multi_media->move(public_path('assets/images/servicemedia'),$medianame);

                $data[] = [
                    'media' => $medianame,
                    'service_id' => $service_id
                ];
            }
            service_media::insert($data);
        }

        return redirect('admin/services')->with('Insert_Message','Data Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $service_media = service_media::where('service_id',$id)->get();

       return view('admin.Services.view',compact('service_media','id'));
    }


    public function update_media(Request $request, $id)
    {
        $service_media = service_media::find($id);

        if($request->media != ''){

            $multi_media = $request->file('media');
            $medianame = rand().time().'.'.$multi_media->extension();
            $multi_media->move(public_path('assets/images/servicemedia'),$medianame);
            $service_media->media = $medianame;
        }
        $service_media->save();

        return redirect()->back()->with('update_message','Data Updated Successfully');
    }

    public function add_media(Request $request)
    {
        $request->validate([
            'media'=>'required',
        ]);

        $service_media = new service_media;

        $service_media->service_id = $request->service_id;

        $multi_media = $request->file('media');
        $medianame = rand().time().'.'.$multi_media->extension();
        $multi_media->move(public_path('assets/images/servicemedia'),$medianame);
        $service_media->media = $medianame;

        $service_media->save();
        return redirect()->back()->with('Insert_Message','Data Created Successfully');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $service = Service::findOrFail($id);
        $categories = Category::all();
        $subcategory = SubCategory::where('category_id', $service->category_id)->get();

        $cities = City::where('status',1)->get();
        $service_city = Service_cities::where('service_id',$id)->pluck('city_id')->toArray();

        return view('admin.Services.edit', compact('service','categories','subcategory','service_city','cities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([

            'category_id'=>'required',
            'sub_category_id'=>'required',
            'city_id'=>'required',
            'title' => 'required',
            'price' => 'required',
            'hour' => 'required',
            'minute' => 'required',
            'description' => 'required',
            'image' => 'mimes:png',
            'banner' => 'mimes:jpg,png,jpeg',
        ]);

        $service = Service::find($id);
        $service->category_id = $request->input('category_id');
        $service->sub_category_id = $request->input('sub_category_id');
        $service->title = $request->input('title');

        if($request->image != ''){
            $image = $request->file('image');
            $imagename = time().'.'.$image->extension();
            $image->move(public_path('assets/images/servicelogo'),$imagename);
            $service->image = $imagename;
        }

        if($request->banner != ''){
            $banner = $request->file('banner');
            $bannername = time().'.'.$banner->extension();
            $banner->move(public_path('assets/images/servicebanner'),$bannername);
            $service->banner = $bannername;
        }

        $service->price = $request->input('price');
        $service->hour = $request->input('hour');
        $service->minute = $request->input('minute');
        $service->description = $request->input('description');
        $service->long_description = $request->input('long_description');
        $service->save();

        if(!empty($request->city_id)){
            $service_city = Service_cities::where('service_id',$id)->pluck('city_id')->toArray();
            $cities_id = $request->city_id;
            $service_id = $service->id;

            $data = [];
            foreach($cities_id as $city_id) {
                if(!in_array($city_id, $service_city)){    
                    echo   $city_id;         
                    $data[] = [
                        'city_id' => $city_id,
                        'service_id' => $service_id
                    ];
                }
            }
            $deletable = array_diff($service_city, $cities_id);
            if(!empty($data)){
                Service_cities::insert($data);
            }
            if(!empty($deletable)){
                $delete_service_city = Service_cities::whereIn('city_id', $deletable)->where('service_id',$id);
                $delete_service_city->delete();
            }
        }

        // if(!empty($request->multi_media)){
        //     $service_media = service_media::where('service_id',$id)->pluck('media')->toArray();
        //     $medias_id = $request->multi_media;
        //     $service_id = $service->id;

        //     $data = [];
        //     foreach($medias_id as $media_id){
        //         ()
        //     }
        // }
        
        return redirect('admin/services')->with('update_message','Data Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $service = Service::find($id);
        $service->delete();
        Service_cities::where('service_id',$id)->delete();
        service_media::where('service_id',$id)->delete();
        Services_ratings::where('service_id',$id)->delete();
        Best_service::where('service_id',$id)->delete();
        
        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }

    public function media_destroy($id)
    {
        $service_media = service_media::find($id);
        $service_media->delete();

        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }

}
