<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Orders;
use App\User;
use App\Service;
use App\Package;
use App\Package_service;
use App\Franchises_order;
use App\Franchise;
use Illuminate\Http\Response;
use App\Order_Details;
use Datatables;
use Carbon\Carbon;

class OrdersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function datatables(Request $request)
    {
        
        $datas = Orders::orderBy('id','desc');
        if(isset($request->searchByFromdate) && !empty($request->searchByFromdate)){
            $datefrom =Carbon::createFromFormat('d/m/Y', $request->searchByFromdate)->format('Y-m-d');
            $datas->where(DB::raw('CAST(created_at as date)'), '>=', $datefrom);
            
        }
        if(isset($request->searchByTodate) && !empty($request->searchByTodate)){
            $dateto = Carbon::createFromFormat('d/m/Y', $request->searchByTodate)->format('Y-m-d');
            $datas->where(DB::raw('CAST(created_at as date)'), '<=', $dateto);
        }
        if(isset($request->searchBystatus) && !empty($request->searchBystatus)){
            
            $datas->where('status',$request->searchBystatus);
        }
        $datas = $datas->get();

        return Datatables::of($datas)
            ->addColumn('action', function(Orders $data) {
                
                return '<div class="dropdown"><span class="bx bx-dots-vertical-rounded font-medium-3 dropdown-toggle nav-hide-arrow cursor-pointer" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="menu"></span><div class="dropdown-menu dropdown-menu-right"><a href="javascript:void(0);" data-href="'. route('orders-delete',$data->id). '" class="dropdown-item delete"><i class="bx bx-trash mr-1"></i>Detete</a><a class="dropdown-item" href="'.route('franchises-invoice',$data->id).'"><i class="bx bx-edit-alt mr-1"></i> Invoice Details</a><a class="dropdown-item show-example-btn booking-status" data-status="'.$data->status.'" data-id="'.$data->id.'" om positioned dialog"><i class="bx bx-cog mr-1"></i>Manage Status</a><a class="dropdown-item" href="'.route('orders-details',$data->id).'"><i class="bx bx-list-ul mr-1"></i> view</a></div></div>';
            }) 
            ->rawColumns(['action'])
            ->toJson();
    }


    public function index()
    {
        // $bookings = Orders::select('id','customer_name','order_number','totalQty','pay_amount','status','created_at','updated_at')
        // ->orderBy('id', 'DESC')
        // ->get();

        // ->leftjoin("franchises_orders AS fo",function($join){
        //     $join->on('orders.id', '=', 'fo.orders_id')->whereIN('fo.status',[0,1]);
        // })->groupBy('orders.id')
        
        return view('admin.Orders.index');
    }

    public function delete($id)
    {
        
        $bookings = Orders::findOrFail($id);
        $bookings->delete();
        return response()->json(['success' => 1, 'message' => 'Data Deleted successfully']);
    }

    public function show_orders($id)
    {

        $booking = Orders::with(['user' => function ($query) {
            $query->select('name','id');
        }])
        ->where('id',$id)
        ->first();

        // $booking_detail = Order_Details::where('booking_id',$id)->first()->toArray();

        // if(!empty($booking_detail['booking_details']['packages'])){
        //     foreach($booking_detail['booking_details']['packages'] as $pkey => $packages){
        //         if(!empty($packages['package_services'])){
        //             foreach($packages['package_services'] as $skey => $service){
        //                 $service_data = Service::where('id',$service['service_id'])->first();
        //                 $packages['package_services'][$skey]['title'] = $service_data->title;
        //                 $packages['package_services'][$skey]['price'] = $service_data->price;
        //             }
        //         }
        //         $booking_detail['booking_details']['packages'][$pkey] = $packages;
        //     }
        // }

        return view('admin.Orders.view',compact('booking'));
    }

    public function assign_franchises(Request $request)
    {
        $order_detail = Orders::where('id',$request->id)->first();
        
        $category_id = isset($order_detail->cart['category_id'])? $order_detail->cart['category_id'] : '';
        
        if(empty($category_id)){
            if(isset($order_detail->cart['packages']))
            {
                foreach($order_detail->cart['packages'] as $package){
                    $category_id = $package['category_id'];
                }
            }
            if(isset($order_detail->cart['services']))
            {
                foreach($order_detail->cart['services'] as $service){
                    $category_id = $service['category_id'];
                }
            }
        }

        $franchises_order = Franchise::where('category_id',$category_id)->get();

        return response()->json($franchises_order);
    }


}
