<?php

namespace App\Http\Controllers\Front;

use App\Classes\GeniusMailer;
use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\BlogCategory;
use App\Models\Counter;
use App\Models\Generalsetting;
use App\Models\Order;
use App\Models\Product;
use App\Models\Subscriber;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use InvalidArgumentException;
use Markury\MarkuryPost;


use App\Category;
use App\SubCategory;
use App\Service;
use App\Country;
use App\State;
use App\City;
use App\Lead;
use App\Package;
use App\Package_service;
use App\My_cart;
use App\Offer;
use Carbon\CarbonPeriod;
use App\User_address;
use App\Orders;
use Illuminate\Support\Str;
use App\Services_ratings;
use App\Packages_ratings;
use App\Franchise;
use App\Franchises_order;
use App\Best_service;
use App\contact_us;
use Auth;

class FrontendController extends Controller
{

    public function __construct()
    {

        //$this->auth_guests();
        // if(isset($_SERVER['HTTP_REFERER'])){
        //     $referral = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        //     if ($referral != $_SERVER['SERVER_NAME']){

        //         $brwsr = Counter::where('type','browser')->where('referral',$this->getOS());
        //         if($brwsr->count() > 0){
        //             $brwsr = $brwsr->first();
        //             $tbrwsr['total_count']= $brwsr->total_count + 1;
        //             $brwsr->update($tbrwsr);
        //         }else{
        //             $newbrws = new Counter();
        //             $newbrws['referral']= $this->getOS();
        //             $newbrws['type']= "browser";
        //             $newbrws['total_count']= 1;
        //             $newbrws->save();
        //         }

        //         $count = Counter::where('referral',$referral);
        //         if($count->count() > 0){
        //             $counts = $count->first();
        //             $tcount['total_count']= $counts->total_count + 1;
        //             $counts->update($tcount);
        //         }else{
        //             $newcount = new Counter();
        //             $newcount['referral']= $referral;
        //             $newcount['total_count']= 1;
        //             $newcount->save();
        //         }
        //     }
        // }else{
        //     $brwsr = Counter::where('type','browser')->where('referral',$this->getOS());
        //     if($brwsr->count() > 0){
        //         $brwsr = $brwsr->first();
        //         $tbrwsr['total_count']= $brwsr->total_count + 1;
        //         $brwsr->update($tbrwsr);
        //     }else{
        //         $newbrws = new Counter();
        //         $newbrws['referral']= $this->getOS();
        //         $newbrws['type']= "browser";
        //         $newbrws['total_count']= 1;
        //         $newbrws->save();
        //     }
        // }
    }

    function getOS() {

        $user_agent     =   !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "Unknown";

        $os_platform    =   "Unknown OS Platform";

        $os_array       =   array(
            '/windows nt 10/i'     =>  'Windows 10',
            '/windows nt 6.3/i'     =>  'Windows 8.1',
            '/windows nt 6.2/i'     =>  'Windows 8',
            '/windows nt 6.1/i'     =>  'Windows 7',
            '/windows nt 6.0/i'     =>  'Windows Vista',
            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
            '/windows nt 5.1/i'     =>  'Windows XP',
            '/windows xp/i'         =>  'Windows XP',
            '/windows nt 5.0/i'     =>  'Windows 2000',
            '/windows me/i'         =>  'Windows ME',
            '/win98/i'              =>  'Windows 98',
            '/win95/i'              =>  'Windows 95',
            '/win16/i'              =>  'Windows 3.11',
            '/macintosh|mac os x/i' =>  'Mac OS X',
            '/mac_powerpc/i'        =>  'Mac OS 9',
            '/linux/i'              =>  'Linux',
            '/ubuntu/i'             =>  'Ubuntu',
            '/iphone/i'             =>  'iPhone',
            '/ipod/i'               =>  'iPod',
            '/ipad/i'               =>  'iPad',
            '/android/i'            =>  'Android',
            '/blackberry/i'         =>  'BlackBerry',
            '/webos/i'              =>  'Mobile'
        );

        foreach ($os_array as $regex => $value) {

            if (preg_match($regex, $user_agent)) {
                $os_platform    =   $value;
            }

        }
        return $os_platform;
    }


// -------------------------------- HOME PAGE SECTION ----------------------------------------

    public function get_location_city($location_search)
    {
        $country_name = $location_search['country'];
        $state_name = $location_search['state'];
        $city_name = $location_search['city'];

        $get_city = Country::where(['countries.name' => $country_name, 'countries.status' => 1])
            ->join("states AS s", function ($join) use ($state_name) {
                $join->on('countries.id', '=', 's.country_id')->where(['s.status' => 1, 's.name' => $state_name]);
            })
            ->join("cities AS c", function ($join) use ($city_name) {
                $join->on('s.id', '=', 'c.state_id')->where(['c.status' => 1, 'c.name' => $city_name]);
            })
            ->first();

        $city_id = null;
        if ($get_city) {
            $city_id = $get_city->id;
        }
        return $city_id;
    }
    public function index()
    {
        $cat = Category::where(['categories.status' => 1]);
        //Session::forget('location_search');
        if (Session::has('location_search')) {

            $location_search = Session::get('location_search');

            $city_id = $this->get_location_city($location_search);
           // $city_id = '';



            $cat->leftjoin("services AS s", function ($join) use ($city_id) {
                $join->on('categories.id', '=', 's.category_id')
                    ->join('service_cities As sc', function ($sub_join) use ($city_id) {
                        return $sub_join->on('sc.service_id', '=', 's.id');
                    })
                    ->where(['sc.city_id' => $city_id])
                    ->where('s.status', 1);
            })
            ->leftjoin("package_categories AS pc", function ($join) use ($city_id) {
                $join->on('pc.category_id', '=', 'categories.id')
                    ->join('packages As p', function ($sub_join) use ($city_id) {
                        $sub_join->on('p.id', '=', 'pc.package_id');
                    })
                    ->join('package_cities As pcity', function ($sub_join) use ($city_id) {
                        $sub_join->on('p.id', '=', 'pcity.package_id');
                    })
                    ->where(['pcity.city_id' => $city_id])
                    ->where('p.status', 1);
            })
            ->select('categories.*',  DB::raw('count(s.category_id) as service_count'),  DB::raw('count(pc.category_id) as package_count'))
            ->havingRaw('service_count > 0 OR package_count > 0');
            //echo $city_id;die;
        }
        $cat = $cat->groupBy('categories.id')->get();

        //$subcategories = SubCategory::select('id','category_id','title','slug','note','logo','sub_note','status')->get();

        $categories = $cat->chunk(8);

        $Best_services = Best_service::with(['service'])->where(['status' => 1])->get();

        $customer_reviews = Services_ratings::with(['user' => function($query){
            $query->select('name','id');
        }])
        ->select(['id','service_id','user_id','service_rating','description'])->where(['status' => 1])->limit(12)->get();

        return view('front.index', compact('categories','Best_services','customer_reviews'));
    }


    public function about()
    {
        return view('front.about');
    }

    public function registerProfessional()
    {
        $id = Auth::id();
        $country = Country::where('status', 1)->get();
        return view('front.registerProfessional', compact('country'));
    }
    public function getState(Request $request) {
        $country_id = $request->country_id;
        $state['states'] = State::where('country_id', $country_id)->where('status', 1)->get();
        return response()->json($state);
    }

    public function getCity(Request $request)
    {
        $state_id = $request->state_id;
        $city['city'] = City::where('state_id', $state_id)->where('status', 1)->get();
        return response()->json($city);
    }
    public function areaCategory()
    {
        return view('front.areaCategory');
    }

    public function gifts()
    {
        return view('front.gifts');
    }

    public function serviceList(Request $request, $cat_slug, $sub_cat_slug = null)
    {
        if (!Session::has('location_search')) {
            return redirect('/');
        }

        $location_search = Session::get('location_search');
        $city_id = $this->get_location_city($location_search);

        $cat = Category::where('slug', $cat_slug)->first();
        $category_id = $cat->id;
        $sub_cat = SubCategory::where(['category_id' => $cat->id, 'status' => 1])->get();

        $all_packages = Package::with(['package_services' => function ($query) {
            $query->select('*')->with(['service']);
        }])
        ->select('packages.*', DB::raw('count(pr.id) as review_count'), DB::raw('avg(pr.package_rating) as review_avg'))
        ->join('package_categories AS pc', function($join){
            $join->on('pc.package_id', '=', 'packages.id');
        })
        ->join('package_cities As pcity', function ($sub_join) use ($city_id) {
            $sub_join->on('packages.id', '=', 'pcity.package_id');
        })
        ->where(['pcity.city_id' => $city_id])
        ->where('pc.category_id', $category_id)
        ->leftJoin('packages_ratings As pr', function ($join) {
            $join->on('pr.package_id', '=', 'packages.id');
        });

        $sub_category = null;
        if (!empty($sub_cat_slug)) {
            $sub_category = SubCategory::where('slug', $sub_cat_slug)->first();
            $sub_category_id = $sub_category->id;

            $all_packages->where('sub_category_id', $sub_category_id);
        }
        $all_packages = $all_packages->select(['packages.*',])->groupBy('packages.id')->get();

        // echo '<pre>';
        // print_R($all_packages);die;

        $services = Service::with(['service_media'])
            ->select('services.*', DB::raw('count(sr.id) as review_count'), DB::raw('avg(sr.service_rating) as review_avg'))->where(['services.status' => 1, 'services.category_id' => $category_id]);
        if (!empty($sub_cat_slug)) {
            $services->where('services.sub_category_id', $sub_category_id);
        }


        $services->join('service_cities As sc', function ($join) use ($city_id) {
            $join->on('sc.service_id', '=', 'services.id');
        })
        ->leftJoin('services_ratings As sr', function ($join) {
            $join->on('sr.service_id', '=', 'services.id');
        })
        ->where(['sc.city_id' => $city_id])
        ->groupBy('services.id');

        $services = $services->get();
// echo '<pre>';
// print_R($services);die;
        $where = [
            'services_ratings.status' => 1,
            'category_id' => $category_id
        ];

        if (!empty($sub_cat_slug)) {
            $where['sub_category_id'] = $sub_category_id;
        }

        $Services_ratings = Services_ratings::where($where)->join('services', 'services.id', '=', 'services_ratings.service_id')->get();
        /*start code for package ratings */
        $Packages_ratings = Packages_ratings::where(['packages_ratings.status' => 1])->join('packages', 'packages.id', '=', 'packages_ratings.package_id')->get();
        $total_review_count_package = count($Packages_ratings);

        $collection_package = collect($Packages_ratings);

        $total_review_package = $collection_package->sum('package_rating');
        $review_ratingss_package = !empty($total_review_count_package) ? ($total_review_package / $total_review_count_package) : 0;
        $review_ratings_package = round($review_ratingss_package, 1);

        /*end code for package ratings */

        /*Start Code for Service Ratings */
        $total_review_count_service = count($Services_ratings);

        $collection_service = collect($Services_ratings);

        $total_review_service = $collection_service->sum('service_rating');
        $review_ratingss_service = !empty($total_review_count_service) ? ($total_review_service / $total_review_count_service) : 0;
        $review_ratings_service = round($review_ratingss_service, 1);
        /*End Code For Service Ratings */

        /*Start Code For Sum of Rating of Packages and Services*/
        $total_review = $total_review_package + $total_review_service;
        $total_review_ratings = $review_ratingss_package + $review_ratingss_service;
        $total_review_count = $total_review_count_service + $total_review_count_package;
        $review_ratingss = !empty($total_review_ratings) ? ($total_review / $total_review_count) : 0;
        $review_ratings = round($review_ratingss, 1);
        /*End Code For Sum of Rating of Packages and Services */

        /* $total_review_count = count($Services_ratings);

        $collection = collect($Services_ratings);

        $total_review = $collection->sum('service_rating');
        $review_ratingss = !empty($total_review_count) ? ($total_review/$total_review_count) : 0;
        $review_ratings = round($review_ratingss,1);   */

        // return view('front.services',compact('cat', 'sub_cat','all_packages','services', 'total_review', 'review_ratings', 'total_review_count'));

        $my_cart = [];
        if (Auth::check()) {
            $id = Auth::user()->id;
            $My_cart = My_cart::where('user_id', $id)->first();
            if($My_cart){
                $my_cart = $My_cart->cart_data;
            }
        }
        $my_cart = Session::has('my_cart') ? Session::get('my_cart') : $my_cart;

        //   echo '<pre>';
        //   print_R($my_cart);die;
        return view('front.services', compact('cat', 'sub_cat', 'all_packages', 'services', 'total_review', 'review_ratings', 'total_review_count', 'my_cart','sub_cat_slug','sub_category'));
    }

    public function register(Request $request, $countries, $states, $cities)
    {
        $user_id = Auth::id();
        $country = $countries;
        $state = $states;
        $city = $cities;
        return view('front.register', compact('user_id', 'country', 'state', 'city'));
    }

    public function addProfessionalUser(Request $request)
    {

        $request->validate([
            'country_id' => 'required',
            'state_id' => 'required',
            'name' => 'required|string|max:50',
            'city_id' => 'required',
            'email' => 'required|string|email|max:255|unique:admins|unique:leads',
            'phone' => 'required|numeric|unique:admins|unique:leads',
            'skill' => 'required',
        ], [
            'country_id.required' => 'Please select your country',
            'state_id.required' => 'Please select your state',
            'name.required' => 'Please enter your name',
            'city_id.required' => 'Please select your city',
            'email.required' => 'Please enter your email',
            'phone.required' => 'Please enter your phone number',
            'skill.required' => 'Please enter what do you do ?'
        ]);

        $country_id = $request->country_id;
        $state_id = $request->state_id;
        $city_id = $request->city_id;

        $data = [
            'name' => $request->name,
            'country_id' => $country_id,
            'state_id' => $state_id,
            'city_id' => $city_id,
            'email' => $request->email,
            'phone' => $request->phone,
            'skill' => $request->skill
        ];
        $user = Lead::create($data);
        return redirect('/Register-as-Professional')->with('success', 'Registration done successfully');
    }

    public function viewpackage(Request $request)
    {
        $package_id = $request->package_id;
        $package = Package_service::where('package_id', $package_id)->get();
        $package_array = array();
        foreach ($package as $mypackage) {
            $package_array[] = $mypackage['service_id'];
        }
        $service = Service::whereIn('id', $package_array)->get();
        return $service;
    }

    public function add_cart_detail(Request $request) {

        $service_data = array();
        $package_array = array();
        if ($request->package_name) {
            $package_array = $request->package_name;
            $all_package_id = array();
            foreach ($package_array as $package => $value) {
                $all_package_id[] = $value;
            }
            $package = Package::whereIn('id', $all_package_id)->get();
            $package_array = array();
            $package_service_array = array();
            $service_array = array();
            $a = 0;
            foreach ($package as $pack) {
                $package_array[$a]['package']['package_id'] = $pack->id;
                $package_array[$a]['package']['package_name'] = $pack->title;
                $package_array[$a]['package']['discount_type'] = $pack->discount_type;
                $package_array[$a]['package']['discount_value'] = $pack->discount_value;
                $package_service = Package_service::where('package_id', $pack->id)->get();
                foreach ($package_service as $pack_service => $val) {
                    $package_service_array[] = $val->service_id;
                }
                $service = Service::whereIn('id', $package_service_array)->get();
                $b = 0;
                foreach ($service as $serve) {
                    $package_array[$a]['package'][$b]['service']['service_id'] = $serve->id;
                    $package_array[$a]['package'][$b]['service']['service_name'] = $serve->title;
                    $package_array[$a]['package'][$b]['service']['service_price'] = $serve->price;
                    $b++;
                }
                $a++;
            }
            if ($request->service_name) {
                $service_name = $request->service_name;
                foreach ($service_name as $served => $value) {
                    $service_data[] = $value;
                }
                $services = Service::whereIn('id', $service_data)->get();
                $b = 0;
                foreach ($services as $serve) {
                    $package_array[$b]['services']['service_id'] = $serve->id;
                    $package_array[$b]['services']['service_name'] = $serve->title;
                    $package_array[$b]['services']['service_price'] = $serve->price;
                    $b++;
                }
            }
        } else {
            $service_name = $request->service_name;
            foreach ($service_name as $served => $value) {
                $service_data[] = $value;
            }
            $services = Service::whereIn('id', $service_data)->get();
            $b = 0;
            foreach ($services as $serve) {
                $package_array[$b]['services']['service_id'] = $serve->id;
                $package_array[$b]['services']['service_name'] = $serve->title;
                $package_array[$b]['services']['service_price'] = $serve->price;
                $b++;
            }
        }
        $data =  $package_array;
        if (Auth::check()) {
            $user_id = Auth::user()->id;
            $cart_detail = new Cart_detail;
            $cart_detail->user_id = $user_id;
            $cart_detail->detail = json_encode($data);
        } else {
            $_SESSION['cart_detali'] = json_encode($data);
        }
    }

    public function create_cart_session(Request $request)
    {

        $my_cart_data = $request->my_cart;
        if (!empty($my_cart_data['packages'])) {
            $collection = collect($my_cart_data['packages']);
            $my_cart_data['packages'] = $collection->mapWithKeys(function ($item) {
                return [$item['id'] => $item];
            })->toArray();
        }
        if (!empty($my_cart_data['services'])) {
            $collection = collect($my_cart_data['services']);
            $my_cart_data['services'] = $collection->mapWithKeys(function ($item) {
                return [$item['id'] => $item];
            })->toArray();
        }
        Session::put('my_cart', $my_cart_data);
        if (Auth::check()) {
            $id = Auth::user()->id;

            $My_cart = My_cart::where('user_id', $id)->first();
            if ($My_cart) {
                $My_cart->cart_data = $my_cart_data;
                $My_cart->save();
            } else {

                $My_cart = new My_cart;
                $My_cart->user_id = $id;
                $My_cart->cart_data = $my_cart_data;
                $My_cart->save();
            }
        }

        if (!session()->has('user.url.intended')) {
            session(['user.url.intended' =>  route('mycart')]);
        }
        return response()->json(['success' => 1, 'isUserLogin' => Auth::check()]);
    }

    public function mycart() {
        $my_cart_data = Session::get('my_cart');
        if (Auth::check()) {
            $id = Auth::user()->id;
            $My_cart = My_cart::where('user_id', $id)->first();
            if (!empty($my_cart_data)) {
                if ($My_cart) {
                    $My_cart->cart_data = $my_cart_data;
                    $My_cart->save();
                } else {

                    $My_cart = new My_cart;
                    $My_cart->user_id = $id;
                    $My_cart->cart_data = $my_cart_data;
                    $My_cart->save();
                }
            } else {
                if(!empty($My_cart)){
                    $my_cart_data = $My_cart->cart_data;
                    Session::put('my_cart', $my_cart_data);
                }
            }
        }

        if (!empty($my_cart_data['packages'])) {
            foreach ($my_cart_data['packages'] as $key => $value) {
                $package = Package::with(['package_services' => function ($query) use ($value) {
                    $query->with(['service'])->whereIn('service_id', $value['services']);
                }])->where('id', $value['id'])->first()->toArray();
                if (!empty($package)) {
                    $package['quantity'] = $value['quantity'];
                    $package['price'] = $value['price'];
                    $package['original_price'] = $value['original_price'];
                    $package['services'] = $value['services'];
                    $my_cart_data['packages'][$key] = $package;
                } else {
                    unset($my_cart_data['packages'][$key]);
                }
            }
        }
        if (!empty($my_cart_data['services'])) {
            foreach ($my_cart_data['services'] as $key => $value) {
                $service = Service::where('id', $value['id'])->first()->toArray();
                if (!empty($service)) {
                    $service['quantity'] = $value['quantity'];
                    $service['price'] = $value['price'];
                    $service['original_price'] = $value['original_price'];
                    $my_cart_data['services'][$key] = $service;
                } else {
                    unset($my_cart_data['services'][$key]);
                }
            }
        }

        $today = Carbon::now()->format('Y-m-d');
        $offers = Offer::with(['user_offer' => function ($query) {
            $query->where(['user_id' => Auth::user()->id, 'status' => 1]);
        }])->where('start_date', '<=', $today)->where('end_date', '>=', $today)->where(['status' => 1])->get();

        foreach ($offers as $k => $offer) {
            if ($offer['is_user_specific'] == 1 && empty($offer['user_offer'])) {
                unset($offers[$k]);
            }
        }
        // echo '<pre>';
        // print_R($my_cart_data);die;
        return view('users.mycart', compact('my_cart_data', 'offers'));
    }

    public function apply_offer(Request $request)
    {
        $user_id = Auth::user()->id;


        $today = Carbon::now()->format('Y-m-d');
        $offer = Offer::with(['user_offer' => function ($query) {
            $query->where(['user_id' => Auth::user()->id, 'status' => 1]);
        }])->where('start_date', '<=', $today)->where('end_date', '>=', $today)->where(['status' => 1, 'offer_code' => $request->offer_code])->first();


        if (!empty($offer)) {

            if ($offer->is_user_specific == 1 && empty($offer['user_offer'])) {
                return response()->json(['success' => 0, 'message' => 'Invalid offer code']);
            } else {
                $my_cart_data = Session::get('my_cart');

                $isOfferApplied = false;
                $total_price = 0;
                $total_applicable_price = 0;
                if (!empty($my_cart_data['packages'])) {
                    foreach ($my_cart_data['packages'] as $package) {
                        $total_price += $package['price'];
                        if ($offer->is_global == 1) {
                            $total_applicable_price += $package['price'];
                            $isOfferApplied = true;
                        }
                    }
                }

                if (!empty($my_cart_data['services'])) {
                    foreach ($my_cart_data['services'] as $service) {
                        $total_price += $service['price'];
                        if ($offer->is_global == 1) {
                            $isOfferApplied = true;
                            $total_applicable_price += $service['price'];
                        } else {
                            $service_data = Service::where('id', $service['id'])->first();
                            $isApplicable = false;
                            if ($offer->category_id == 0 || $offer->category_id == $service_data->category_id) {
                                $isApplicable = true;
                            }
                            if ($isApplicable == true && ($offer->sub_category_id == 0 || $offer->sub_category_id == $service_data->sub_category_id)) {
                                $isApplicable = true;
                            } else {
                                $isApplicable = false;
                            }
                            if ($isApplicable == true && ($offer->service_id == 0 || $offer->service_id == $service_data->id)) {
                                $isApplicable = true;
                            } else {
                                $isApplicable = false;
                            }
                            if ($isApplicable == true) {
                                $isOfferApplied = true;
                                $total_applicable_price += $service['price'];
                            }
                        }
                    }
                }

                if ($isOfferApplied == true) {
                    $discount = 0;
                    if ($offer->offer_type == 0) {
                        $discount = $offer->offer_value;
                    } else {
                        $discount = (($total_applicable_price * $offer->offer_value) / 100);
                        if ($discount > $offer->max_value) {
                            $discount = $offer->max_value;
                        }
                    }

                    $new_price = $total_price - $discount;

                    $offer->total_price = number_format($total_price,2,'.','');
                    $offer->new_price = number_format($new_price,2,'.','');
                    $offer->discount = number_format($discount,2,'.','');
                    return response()->json(['success' => 1, 'message' => 'Offer code applied successfully.', 'offer_data' => $offer]);
                } else {
                    return response()->json(['success' => 0, 'message' => 'Offer code not applicable to your order.']);
                }
            }
        }
        return response()->json(['success' => 0, 'message' => 'Invalid offer code']);
    }

    public function add_final_price(Request $request) {
        $My_cart = My_cart::where('user_id', Auth::user()->id)->first();
        if ($My_cart) {
            $My_cart->cart_data = array_merge($My_cart->cart_data, $request->data);
            $My_cart->save();
            return response()->json(['success' => 1, 'message' => 'success']);
        }
        return response()->json(['success' => 0, 'message' => 'Something went wrong']);
    }

    public function address()  {
        $User_address = User_address::where('user_id', Auth::user()->id)->get();


        $day_array = [];

        for ($i = 0; $i < 3; $i++) {
            $start = Carbon::now();
            $date = $start->addDay($i);
            if ($i == 0) {
                $start_hour = $date->addHour(1)->format('H:' . '00');
            } else {
                $start_hour = '07:00';
            }
            $period = new CarbonPeriod($start_hour, '30 minutes', '23:30'); // for create use 24 hours format later change format
            $slots = [];
            foreach ($period as $item) {
                array_push($slots, $item->format("h:i A"));
            }

            if ($i == 0) {
                $day_name = 'Today';
            } elseif ($i == 1) {
                $day_name = 'Tomorrow';
            } else {
                $day_name = $date->format('D');
            }
            $day_array[] = [
                'date' => $date->format('Y-m-d'),
                'human_date' => $date->format('d/m/Y'),
                'slots' => $slots,
                'day_name' => $day_name,
                'day' => $date->format('d'),
            ];
        }

        return view('users.address', compact('User_address', 'day_array'));
    }

    public function save_user_address(Request $request) {

        $validator = $request->validate([
            'flat_building_no' => 'required',
            'name' => 'required',
            'type' => 'required',
            'lat' => 'required'
        ],[
            'lat.required' => 'Please enter valid address',
        ]);

        $address = User_address::where(['user_id' => Auth::user()->id, 'type' => $request->type])->first();
        if ($address) {
            $address->user_id = Auth::user()->id;
            $address->flat_building_no = $request->flat_building_no;
            $address->name = $request->name;
            $address->address = $request->address;
            $address->type = $request->type;
            $address->country = $request->country;
            $address->state = $request->state;
            $address->city = $request->city;
            $address->zip = $request->zip;
            $address->latitude = $request->lat;
            $address->longitude = $request->lng;
            $address->save();
            return redirect()->route('user.address')->with('success', 'Address saved successfully');
        } else {
            $address = new User_address;
            $address->user_id = Auth::user()->id;
            $address->flat_building_no = $request->flat_building_no;
            $address->name = $request->name;
            $address->address = $request->address;
            $address->type = $request->type;
            $address->country = $request->country;
            $address->state = $request->state;
            $address->city = $request->city;
            $address->zip = $request->zip;
            $address->latitude = $request->lat;
            $address->longitude = $request->lng;

            $address->save();
            return redirect()->route('user.address')->with('success', 'Address saved successfully');
        }
    }

    public function save_address_time_slot(Request $request) {

        $My_cart = My_cart::where('user_id', Auth::user()->id)->first();
        if ($My_cart) {
            $data['slot_date'] = Carbon::createFromFormat('d/m/Y', $request->data['slot_date'])->format('Y-m-d');;
            $data['slot_time'] = $request->data['slot_time'];

            $address = User_address::where(['user_id' => Auth::user()->id, 'id' => $request->data['address_id']])->first();
            $data['flat_building_no'] = $address->flat_building_no;
            $data['address'] = $address->address;
            $data['address_id'] = $address->id;
            $data['customer_name'] = $address->name;

            $My_cart->cart_data = array_merge($My_cart->cart_data, $data);
            $My_cart->save();
            return response()->json(['success' => 1, 'message' => 'success']);
        }
        return response()->json(['success' => 0, 'message' => 'Something went wrong']);
    }

    public function payment_method() {

        $My_cart = My_cart::where('user_id', Auth::user()->id)->first();
        if (!$My_cart) {
            return redirect('/')->with('Insert_Message', 'Cart Is empty');
        }
        $cart_data = $My_cart->cart_data;
        $total_quantity = 0;
        if (!empty($cart_data['packages'])) {
            foreach ($cart_data['packages'] as $package) {
                $total_quantity += $package['quantity'];
            }
        }
        if (!empty($cart_data['services'])) {
            foreach ($cart_data['services'] as $service) {
                $total_quantity += $service['quantity'];
            }
        }
        return view('users.payment-method', compact('cart_data', 'total_quantity'));
    }

    public function place_order(Request $request) {
        $validator = $request->validate([
            'payment_method_type' => 'required',
        ], ['payment_method_type.required' => 'Please select payment option']);

        $My_cart = My_cart::where('user_id', Auth::user()->id)->first();
        $cart_data = $My_cart->cart_data;
        if (!empty($cart_data['packages'])) {
            foreach ($cart_data['packages'] as $p => $package) {
                $get_package = Package::where('id', $package['id'])->first()->toArray();
                $package_service = Service::whereIn('id', $package['services'])->get()->toArray();
                $cart_data['packages'][$p] = array_merge($package, $get_package);
                $cart_data['packages'][$p]['package_service'] = $package_service;
            }
        }
        if (!empty($cart_data['services'])) {
            foreach ($cart_data['services'] as $s => $service) {
                $get_service = Service::where('id', $service['id'])->first()->toArray();
                $cart_data['services'][$s] = array_merge($service, $get_service);
            }
        }

        $payment_type = $request->payment_method_type;
        $total_quantity = 0;
        if (!empty($cart_data['packages'])) {
            foreach ($cart_data['packages'] as $package) {
                $total_quantity += $package['quantity'];
            }
        }
        if (!empty($cart_data['services'])) {
            foreach ($cart_data['services'] as $service) {
                $total_quantity += $service['quantity'];
            }
        }

        $address = User_address::where(['user_id' => Auth::user()->id, 'id' => $cart_data['address_id']])->first();

        // Get frenchise with match city and cancellation retio desc
        $franchises = Franchise::where(['franchises.status' => 1])
            ->with(['franchise_categories'])
            ->select(['franchises.*', DB::raw('count(franchises_id) as cancel_count')])
            //->leftjoin('franchises_orders AS fo', 'franchises.id', '=', 'fo.franchises_id')
            ->join("cities AS c", function ($join)  {
                $join->on('c.id', '=', 'franchises.city_id');
            })
            ->join("states AS s", function ($join)  {
                $join->on('s.id', '=', 'c.state_id');
            })
            ->join("countries", function ($join) {
                $join->on('countries.id', '=', 's.country_id');
            })
            ->leftjoin("franchises_orders AS fo", function ($join) {
                $join->on('franchises.id', '=', 'fo.franchises_id')->where('fo.status', 2);
            })
            ->where(['countries.name' => $address->country],['s.name' => $address->state],['c.name' => $address->city])
            ->orderBy('cancel_count', 'ASC')
            ->orderBy('franchises.id', 'DESC')
            ->groupBy('franchises.id')
            ->get()->map(function($query){
                $query->f_categories = $query->franchise_categories->pluck('category_id')->toArray();
                return $query;
            });



        if($franchises->count()){

            // Group by franchise id
            $franchise_data = [];
            if(!empty($cart_data['packages'])){
                foreach($cart_data['packages'] as $k => $package){
                    $franchise_data[$package['franchises_id']]['packages'][$k] = $package;
                }
            }
            if(!empty($cart_data['services'])){
                foreach($cart_data['services'] as $k => $service){
                    $franchise_data[$service['franchises_id']]['services'][$k] = $service;
                }
            }


           $order_datetime = Carbon::parse($cart_data['slot_date'] . $cart_data['slot_time']);
           $order_datetime1 = $order_datetime->format('Y-m-d H:i:s');

            $order_assign = [];
            foreach($franchises as $franchise){
                if(isset($franchise_data[$franchise->id])){
                    $order_datetime = Carbon::parse($order_datetime1);
                    $order_datetime1 = $order_datetime->format('Y-m-d H:i:s');

                    $time_required = 0; // in minute
                    if(!empty($franchise_data[$franchise->id]['services'])){
                        foreach($franchise_data[$franchise->id]['services'] as $value){
                            if(!empty($value['hour'])){
                                $time_required += $value['hour'] * 60;
                            }
                            if(!empty($value['minute'])){
                                $time_required += $value['minute'];
                            }
                        }
                    }

                    if(!empty($franchise_data[$franchise->id]['packages'])){
                        foreach($franchise_data[$franchise->id]['packages'] as $p_value){
                            foreach($p_value['package_service'] as $value){
                                if(!empty($value['hour'])){
                                    $time_required += $value['hour'] * 60;
                                }
                                if(!empty($value['minute'])){
                                    $time_required += $value['minute'];
                                }
                            }
                        }
                    }


                    $order_datetime2 = $order_datetime->addMinute($time_required)->format('Y-m-d H:i:s');
                    $order_datetime = $order_datetime2;

                    $franchises_orders = Franchises_order::where(['franchises_id' => $franchise->id])
                        ->where(function($query) use($order_datetime1, $order_datetime2){
                            $query->whereBetween('start_time', [$order_datetime1, $order_datetime2])
                            ->OrwhereBetween('end_time', [$order_datetime1, $order_datetime2]);
                        })
                        ->get();
                    if($franchises_orders->count() == 0){
                        $order_assign[$franchise->id] = [
                            'franchises_id' => $franchise->id,
                            'data' => $franchise_data[$franchise->id],
                            'take_time' => $time_required,
                            'start_time' => $order_datetime1,
                            'end_time' => $order_datetime2
                        ];
                    }
                    unset($franchise_data[$franchise->id]);
                }
            }

            if(!empty($franchise_data[0])){
                foreach($franchises as $franchise){

                    if(!empty($franchise_data[0]['packages'])){
                        foreach($franchise_data[0]['packages'] as $k => $f_package_data){
                            $assignable_services = 0;
                            $time_required = 0; // in minute
                            foreach($f_package_data['package_service'] as $p_service){
                                if(!empty($p_service['hour'])){
                                    $time_required += $p_service['hour'] * 60;
                                }
                                if(!empty($p_service['minute'])){
                                    $time_required += $p_service['minute'];
                                }
                                if(in_array($p_service['category_id'], $franchise->f_categories)){
                                    $assignable_services++;
                                }
                            }

                            if($assignable_services == count($f_package_data['package_service'])){

                                $order_datetime = Carbon::parse($order_datetime);
                                $order_datetime1 = $order_datetime->format('Y-m-d H:i:s');

                                $order_datetime2 = $order_datetime->addMinute($time_required)->format('Y-m-d H:i:s');
                                $order_datetime = $order_datetime2;

                                $franchises_orders = Franchises_order::where(['franchises_id' => $franchise->id])
                                ->where(function($query) use($order_datetime1, $order_datetime2){
                                    $query->whereBetween('start_time', [$order_datetime1, $order_datetime2])
                                    ->OrwhereBetween('end_time', [$order_datetime1, $order_datetime2]);
                                })
                                ->get();

                                if($franchises_orders->count() == 0){

                                    if(isset($order_assign[$franchise->id])){
                                        $start_time = Carbon::parse($order_assign[$franchise->id]['end_time']);
                                        $end_time = $start_time->addMinute($time_required)->format('Y-m-d H:i:s');

                                        $time_required += $order_assign[$franchise->id]['take_time'];
                                        $data = $order_assign[$franchise->id]['data'];
                                        $data['packages'][] = $f_package_data;

                                        $order_assign[$franchise->id] = [
                                            'franchises_id' => $franchise->id,
                                            'data' => $data,
                                            'take_time' => $time_required,
                                            'start_time' => $order_datetime1,
                                            'end_time' => $end_time
                                        ];
                                    }else{
                                        $data['packages'][] = $f_package_data;
                                        $order_assign[$franchise->id] = [
                                            'franchises_id' => $franchise->id,
                                            'data' => $data,
                                            'take_time' => $time_required,
                                            'start_time' => $order_datetime1,
                                            'end_time' => $order_datetime2
                                        ];
                                    }
                                    unset($franchise_data[0]['packages'][$k]);
                                }
                            }
                        }
                    }

                    if(!empty($franchise_data[0]['services'])){
                        foreach($franchise_data[0]['services'] as $s => $f_service_data){

                            if(in_array($f_service_data['category_id'], $franchise->f_categories)){

                                $time_required = 0; // in minute
                                if(!empty($f_service_data['hour'])){
                                    $time_required += $f_service_data['hour'] * 60;
                                }
                                if(!empty($f_service_data['minute'])){
                                    $time_required += $f_service_data['minute'];
                                }

                                $order_datetime = Carbon::parse($order_datetime);
                                $order_datetime1 = $order_datetime->format('Y-m-d H:i:s');

                                $order_datetime2 = $order_datetime->addMinute($time_required)->format('Y-m-d H:i:s');
                                $order_datetime = $order_datetime2;

                                $franchises_orders = Franchises_order::where(['franchises_id' => $franchise->id])
                                ->where(function($query) use($order_datetime1, $order_datetime2){
                                    $query->whereBetween('start_time', [$order_datetime1, $order_datetime2])
                                    ->OrwhereBetween('end_time', [$order_datetime1, $order_datetime2]);
                                })
                                ->get();

                                if($franchises_orders->count() == 0){

                                    if(isset($order_assign[$franchise->id])){
                                        $time_required += $order_assign[$franchise->id]['take_time'];
                                        $start_time = Carbon::parse($order_assign[$franchise->id]['end_time']);
                                        $end_time = $start_time->addMinute($time_required)->format('Y-m-d H:i:s');



                                        $data = $order_assign[$franchise->id]['data'];
                                        $data['services'][] = $f_service_data;

                                        $order_assign[$franchise->id] = [
                                            'franchises_id' => $franchise->id,
                                            'data' => $data,
                                            'take_time' => $time_required,
                                            'start_time' => $order_datetime1,
                                            'end_time' => $end_time
                                        ];
                                    }else{
                                        $data['services'][] = $f_service_data;
                                        $order_assign[$franchise->id] = [
                                            'franchises_id' => $franchise->id,
                                            'data' => $data,
                                            'take_time' => $time_required,
                                            'start_time' => $order_datetime1,
                                            'end_time' => $order_datetime2
                                        ];
                                    }
                                    unset($franchise_data[0]['services'][$s]);
                                }
                            }
                        }
                    }
                }
            }

            $is_order_place = true;
            if(!empty($franchise_data)){
                foreach($franchise_data as $fdata){
                    if(!empty($fdata['packages'])){
                        $is_order_place = false;
                    }
                    if(!empty($fdata['services'])){
                        $is_order_place = false;
                    }
                }
            }

           // $is_order_place = false;
            if($is_order_place == true){
                // var_dump($is_order_place);
                // echo '<pre>';
                // print_R($order_assign);
                // die;

                $cart_data['payment_type'] = $payment_type;
                $item_number = Str::random(4) . time();
                $order = new Orders;
                $order->user_id = Auth::user()->id;
                $order->cart = $cart_data;
                $order->method = $payment_type;
                $order['user_id'] = Auth::user()->id;
                $order['cart'] = $cart_data;
                $order['totalQty'] = $total_quantity;
                $order['pay_amount'] = $cart_data['final_total'];
                $order['method'] = $payment_type;
                $order['customer_email'] = Auth::user()->email;
                $order['customer_name'] = $cart_data['customer_name'];
                $order['customer_phone'] = Auth::user()->mobile;
                $order['order_number'] = $item_number;
                $order['customer_address'] = $cart_data['address'];
                $order['coupon_code'] = $cart_data['offer_code'];
                $order['coupon_discount'] = $cart_data['discount'];
                $order['payment_status'] = "Pending";
                $order->save();

                foreach($order_assign as $assign){
                    $Franchise = new Franchises_order;
                    $Franchise->franchises_id = $assign['franchises_id'];
                    $Franchise->orders_id = $order->id;
                    $Franchise->take_time = $assign['take_time'];
                    $Franchise->order_details = $assign['data'];
                    $Franchise->start_time = $assign['start_time'];
                    $Franchise->end_time = $assign['take_time'];
                    // echo '<pre>';
                    // print_R($Franchise);die;
                    $Franchise->save();
                }
                // $getFranchise = Franchise::where(['franchises.status' => 1])->select(['franchises.id', 'franchises.franchise_name', DB::raw('count(franchises_id) as cancel_count')])
                //     ->leftjoin("franchises_orders AS fo", function ($join) {
                //         $join->on('franchises.id', '=', 'fo.franchises_id')->where('fo.status', 2);
                //     })
                //     ->orderBy('cancel_count', 'ASC')
                //     ->groupBy('franchises.id')
                //     ->first();
                // if (!empty($getFranchise)) {
                //     $Franchise = new Franchises_order;
                //     $Franchise->franchises_id = $getFranchise->id;
                //     $Franchise->orders_id = $order->id;
                //     $Franchise->save();
                // }


                Session::forget('my_cart');
                $My_cart = My_cart::where('user_id', Auth::user()->id)->first();
                $My_cart->delete();
                return redirect()->route('user.order_details', $order->id)->with('success', 'Your order received successfullly.');
                //return response()->json(['success' => 1, 'message' => 'success', 'order_id' => $order->id]);

            }else{
                return redirect()->route('user.payment_method')->with('error', 'Currently your order can not process at provided time, please change and try again.');
            }
        }
        return redirect()->route('user.payment_method')->with('error', 'Currently your order can not process.');


    }
    public function order_details($order_id = null)
    {
        if (!$order_id) {
            return redirect('/')->with('Insert_Message', 'Invalid order');
        }
        $my_order = Orders::where('id', $order_id)->first();

        // $category_id = $my_order->cart['category_id'];
        // $catogory = Category::where('id', $category_id)->first();
        return view('users.order_detail', compact('my_order'));
    }

    public function send_review(Request $request)
    {
        if ($request->type == 'package') {
            $package = new Packages_ratings;
            $user_id = Auth::user()->id;
            $exist_review = Packages_ratings::where('user_id', $user_id)->where('package_id', $request->id)->first();

            if (!empty($exist_review)) {
                $exist = $exist_review->id;
                $exist_review_data = Packages_ratings::find($exist);
                if ($request->star_rate == '') {
                    $exist_review_data->package_rating = 0;
                } else {
                    $exist_review_data->package_rating = $request->star_rate;
                }
                $exist_review_data->description = $request->comment;
                $exist_review_data->save();
            } else {
                $package->user_id = $user_id;
                $package->package_id = $request->id;
                if ($request->star_rate == '') {
                    $package->package_rating = 0;
                } else {
                    $package->package_rating = $request->star_rate;
                }
                $package->description = $request->comment;
                $package->save();
            }
        } else {
            $package = new Services_ratings;
            $user_id = Auth::user()->id;
            $exist_review = Services_ratings::where('user_id', $user_id)->where('service_id', $request->id)->first();

            if (!empty($exist_review)) {
                $exist = $exist_review->id;
                $exist_review_data = Services_ratings::find($exist);
                if ($request->star_rate == '') {
                    $exist_review_data->service_rating = 0;
                } else {
                    $exist_review_data->service_rating = $request->star_rate;
                }
                $exist_review_data->description = $request->comment;
                $exist_review_data->save();
            } else {
                $package->user_id = $user_id;
                $package->service_id = $request->id;
                if ($request->star_rate == '') {
                    $package->service_rating = 0;
                } else {
                    $package->service_rating = $request->star_rate;
                }
                $package->description = $request->comment;
                $package->save();
            }
        }
    }

    public function set_location_session(Request $request)
    {
        if (isset($request->clear)) {
            Session::forget('location_search');
            return redirect('/');
        }
        $validator = $request->validate(
            [
                'lat' => 'required',
            ],
            [
                'lat.required' => 'Please enter valid location',
            ]
        );

        $location_search = [
            'location_search' => $request->location_search,
            'lat' => $request->lat,
            'lng' => $request->lng,
            'country' => $request->country,
            'city' => $request->city,
            'state' => $request->state,
            'zip' => $request->zip
        ];
        Session::put('location_search', $location_search);
        return redirect('/');
    }

    public function cancel_order(Request $request, $order_id){
        $user_id = Auth::user()->id;
        $Order = Orders::where(['user_id' => $user_id, 'id' => $order_id])->first();
        if($Order){
            $Order->status = 'cancelled';
            $Order->save();
            return response()->json(['success' => 1, 'message' => 'Order has been cancelled successfully.']);
        }
        return response()->json(['success' => 0, 'message' => 'Invalid access']);

    }

    public function remove_item_from_cart(Request $request){

        $id = $request->id;
        $My_cart = My_cart::where('user_id', Auth::user()->id)->first();
        if ($My_cart) {
            $cart_data = $My_cart->cart_data;
            if($request->type == 'service'){
                if(isset($cart_data['services'][$id])){
                    unset($cart_data['services'][$id]);
                }
                if(empty($cart_data['services'])){
                    unset($cart_data['services']);
                }
            }else{
                if(isset($cart_data['packages'][$id])){
                    unset($cart_data['packages'][$id]);
                }
                if(empty($cart_data['packages'])){
                    unset($cart_data['packages']);
                }
            }

            Session::put('my_cart', $cart_data);
            $My_cart->cart_data = $cart_data;
            $My_cart->save();
            return response()->json(['success' => 1, 'message' => 'Item removed successfully.']);
        }
        return response()->json(['success' => 0, 'message' => 'Something went wrong']);
    }


    public function orders()
    {
        $user = Auth::guard('web')->user();
        $orders = Orders::where('user_id','=',$user->id)->orderBy('id','desc')->get();
        return view('users.orders', compact('orders'));
    }

    public function ongoingorders()
    {
        $user = Auth::guard('web')->user();
        $orders = Orders::where('user_id','=',$user->id)->whereIn('status', ['pending','processing','on delivery'])->orderBy('id','desc')->get();
        return view('users.ongoingorders', compact('orders'));
    }

    public function user_profile()
    {
        $user = Auth::guard('web')->user();

        $countries = Country::all();
        return view('users.user_profile', compact('countries', 'user'));
    }

    public function contact_us(Request $request){
        $request->validate([
            'contact_name' => ['required'],
            'contact_email' => ['required', 'string', 'email', 'max:255'],
            'contact_phone' => ['required', 'numeric', 'digits:10', 'unique:users,phone'],
            'contact_message' => ['required'],
        ], [
            'contact_name.required' => 'Please enter your name',
            'contact_email.required' => 'Please enter your email',
            'contact_phone.required' => 'Please enter your mobile number',
            'contact_message.required' => 'Please enter your message.',
        ]);


        $contact_us = new contact_us;
        $contact_us->name = $request->contact_name;
        $contact_us->email = $request->contact_email;
        $contact_us->phone = $request->contact_phone;
        $contact_us->comment = $request->contact_message;

        $contact_us->save();
        return redirect('/')->with('success', 'Message submitted successfully');
    }






}
