<?php

namespace App\Http\Controllers\Front;

use App\User;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use App\UserLoginLog;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Session;


use Illuminate\Foundation\Auth\AuthenticatesUsers;


class UsersController extends Controller
{

    public function __construct() {
        //$this->middleware(['role:admin|creator']);
        //$this->middleware(['role:user']);
    }


    public function index()
    {
        $user = Auth::user();
        return view('users.dashboard',compact('user'));
    }
    public function indexLoginLogs()
    {
        $userLoginActivities = UserLoginLog::paginate(10);

        return view('admin.activity.logs', compact('userLoginActivities'));
    }


    public function store(Request $request)
    {
        // $validator = \Validator::make($request->all(), [
        //     'name' => 'required|string',
        //     'email' => 'required|string|email|max:255|unique:users',
        //     'mobile' => 'required|numeric|digits:10|unique:users',
        //     'password' => 'required|min:5',
        //     'confirm_password' => 'required|min:5|same:password',
        // ]);

        $rules = [
            'name' => 'required|string',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|numeric|digits:10|unique:users',
            'password' => 'required|min:5',
            'confirm_password' => 'required|min:5|same:password',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return response()->json(array('errors' => $validator->getMessageBag()->first()));
        }

        $user = User::create(array_merge($request->all(),['password' => Hash::make($request->password)]));

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password]))
        {
            // if successful, then redirect to their intended location

            // Login as User
            return response()->json(route('user-dashboard'));
        }

    }

    public function login(Request $request)
    {


        $rules = [
            'email'   => 'required|email',
            'password' => 'required'
          ];

            $validator = Validator::make($request->all(), $rules);
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()]);
            }

            if (Auth::guard('web')->attempt(['email' => $request->email, 'password' => $request->password])) {
                // if successful, then redirect to their intended location
                if(session()->has('user.url.intended')){
                    $url = session()->get('user.url.intended');
                    session()->forget('user.url.intended');
                  }else{
                    $url = route('user-dashboard');
                  }
                  return response()->json($url);
            }
            return response()->json(array('error' => [ 0 => 'Credentials Doesn\'t Match !' ]));
    }





    public function edit($id)
    {

    }

    public function update(Request $request, $id)
    {

    }


    public function destroy($id)
    {

    }


    public function massDestroy(Request $request)
    {

    }

}
