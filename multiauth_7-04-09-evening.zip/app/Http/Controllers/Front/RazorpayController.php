<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
use Session;
use Redirect;
use App\Orders;

class RazorpayController extends Controller
{

    public function payment(Request $request)
    {

        $input = $request->all();

        $order_number = $input['order_number'];
        $api = new Api(env('RAZOR_KEY'), env('RAZOR_SECRET'));


        $success = true;
        $error = "Payment Failed";

        if (empty($_POST['razorpay_payment_id']) === false) {

            try {
                $attributes = array(
                    'razorpay_order_id' => $input['razorpay_order_id'],
                    'razorpay_payment_id' => $input['razorpay_payment_id'],
                    'razorpay_signature' => $input['razorpay_signature']
                );
                $api->utility->verifyPaymentSignature($attributes);
            }  catch(SignatureVerificationError $e) {
                $success = false;
                $error = 'Razorpay Error : ' . $e->getMessage();
            }
        }
        if ($success === true){
            $razorpayOrder = $api->order->fetch($input['razorpay_order_id']);

            $transaction_id = $input['razorpay_payment_id'];
            $order =  Orders::where('order_number', $order_number)->first();

            if (isset($order))  {
                $order->pay_id = $transaction_id;
                $order->payment_status = 'Paid';
                $order->save();

            }
            return redirect()->back()->with(['success' => 'Your payment has been done successfully.']);
        }
        return redirect()->back()->with(['error' => $error]);
    }
}
