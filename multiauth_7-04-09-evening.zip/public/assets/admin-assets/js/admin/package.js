$('#p_category_id').on('change', function () {
    // console.log(e);
    var cat_id = $(this).val();
    var _token = $("#form_package input[name='_token']").val();
    //console.log(cat_id);
    //ajax
    var package_id = '';
    if($('#package_id').length){
        package_id = $('#package_id').val();
    }
    $.ajax({
        url: "/admin/package-subcat",
        type: 'POST',
        data: { cat_id: cat_id, _token: _token, package_id:package_id },
        success: function (data) {
            $('#p_sub_category_id').empty();
            $('#p_sub_category_id').append('<option value ="">Select Sub Category</option>');
            $.each(data, function (inedx, subcatObj) {
                //console.log(subcatObj.title);
                $('#p_sub_category_id').append('<option value ="' + subcatObj.id + '" '+(subcatObj.selected ?'selected':'')+'>' + subcatObj.title + '</option>');
            });
        }
    });

});



$('#p_sub_category_id').on('change', function () {
    // console.log(e);
    var cat_id = $(this).val();
    var _token = $("#form_package input[name='_token']").val();
    //console.log(cat_id);
    //ajax
    var package_id = '';
    if($('#package_id').length){
        package_id = $('#package_id').val();
    }

    $.ajax({
        url: "/admin/package-service",
        type: 'POST',
        data: { cat_id: cat_id, _token: _token,package_id:package_id },
        success: function (data) {
            
            $('#p_service_id').empty();
            $('#p_service_id').append('<option value ="">Select Sub Category</option>');
            $.each(data, function (inedx, subcatObj) {
                //console.log(subcatObj.title);
                $('#p_service_id').append('<option value ="' + subcatObj.id + '" '+(subcatObj.selected ?'selected':'')+'>' + subcatObj.title + '</option>');
            });
        }
    });

});





// $('.itemName').select2({
    
//     //placeholder: 'Select an item',
//     ajax: {
//       url: '/admin/multi-select',
//       dataType: 'json',
//       delay: 250,
//       processResults: function (data) {
//         return {
//           results:  $.map(data, function (item) {
//                 return {
//                     text: item.name,
//                     id: item.id
//                 }
//             })
//         };
//       },
//       cache: true
//     }
// });